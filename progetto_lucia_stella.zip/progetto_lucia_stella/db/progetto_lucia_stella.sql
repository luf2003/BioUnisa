-- Rimuove il database
DROP DATABASE IF EXISTS progetto_lucia_stella;
-- Crea il database
CREATE DATABASE progetto_lucia_stella;
USE progetto_lucia_stella;

-- Specifica l'account user
DROP USER IF EXISTS 'web-account' @localhost;
CREATE USER 'web-account' @localhost IDENTIFIED BY 'password';
GRANT ALL ON progetto_lucia_stella.* TO 'web-account' @localhost;

-- Rimuove la tabella prodotto se esiste già
DROP TABLE IF EXISTS prodotto;
-- Crea la tabella prodotto
CREATE TABLE prodotto (
    idProdotto INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    descrizione VARCHAR(2000),
    categoria VARCHAR(50) CHECK (categoria IN ('Creme Idratanti', 'Detergente viso', 'Sieri', 'Maschere', 'Protezione solare', 'Esfolianti', 'Toner e acque floreali', 'Oli Viso', 'Trattamenti anti-età', 'Make-up naturale', 'Accessori per la cura della pelle')),
    formato VARCHAR(50) CHECK (formato IN ('Non specificato','10 ml', '25 ml', '30 ml','35 ml','50 ml', '100 ml', '200 ml')),
    prezzoUnitario DECIMAL(10, 2) NOT NULL,
    quantitaDisponibile INT,
    percorsoimmagine VARCHAR(500)
);

-- Popolamento della tabella prodotto
INSERT INTO prodotto (idProdotto, nome, descrizione, categoria, formato, prezzoUnitario, quantitaDisponibile, percorsoimmagine) VALUES 
    -- Crema Idratante
    (2, 'Crema Idratante BioUnisa', 'La crema idratante viso BioUnisa è una sinfonia di ingredienti naturali formulata per donare alla vostra pelle un’idratazione profonda e duratura, per tutto il giorno. <br>
	La sua consistenza leggera e vellutata si assorbe istantaneamente, avvolgendovi in un velo di idratazione che rivitalizza e rinnova la vostra pelle, riducendo la secchezza e migliorando visibilmente la sua elasticità. <br>
	Dalle giornate rigide invernali alle estati calde e soleggiate, la nostra crema idratante viso è il vostro alleato quotidiano per una pelle luminosa e radiosa in ogni stagione. <br>
	Concedetevi il lusso di una pelle impeccabile e salutare con la nostra crema idratante viso.  Il segreto per un incarnato splendente e un aspetto giovane e fresco, giorno dopo giorno. <br>
	<b> Formulazione: </b>  Ecobio <br>
	<b>pH: </b>  Fisiologico  <br>', 'Creme Idratanti', '100 ml', 19.99, 200, 'Immagini/cremaviso.jpeg'),
    
    -- Detergente viso
    (4, 'Detergente Viso BioUnisa', 'Con una schiuma cremosa e leggera, il detergente BioUnisa penetra dolcemente nei pori, rimuovendo delicatamente il trucco, l’eccesso di sebo e le impurità ambientali, senza mai lasciare la pelle secca o irritata. <br>
	Arricchito con estratti botanici lenitivi e vitamine nutrienti, ogni utilizzo di questo detergente è un gesto di amore verso la vostra pelle, che si traduce in un incarnato luminoso e fresco. <br>
	Dalle mattine frenetiche ai momenti di relax serali, concedetevi il lusso di una pulizia delicata ma efficace con il nostro detergente viso. Il primo passo verso una pelle splendida e radiosa che riflette la vostra bellezza naturale. <br>
	<b> Formulazione: </b>Ecobio  <br>
	<b> pH: </b> Fisiologico <br>', 'Detergente viso', '50 ml', 25.00, 180, 'Immagini/Detergente.jpeg'),
    
    -- Sieri
    (5, 'Siero BioUnisa', 'Il siero viso BioUnisa è una potente miscela di ingredienti ad alta performance, progettata per combattere i segni dell’invecchiamento e ripristinare la giovinezza della pelle. <br>
	Arricchito con peptidi rassodanti e antiossidanti potenti, questa formula avanzata stimola il processo di rigenerazione della pelle, migliorando la sua texture e riducendo l’aspetto delle rughe e delle linee sottili. <br>
	La sua texture è leggera e setosa avvolgendovi in una sensazione di lusso e benessere. <br>
	Ogni applicazione è un momento di auto-cura e indulgenza, che vi avvicina sempre di più alla vostra migliore versione. <br>
	<b> Formulazione: </b>Ecobio <br>
	<b> Formati disponibili: </b>50ml <br>
	<b> pH: </b> Fisiologico <br> ', 'Sieri', '50 ml', 21.99, 400, 'Immagini/Siero.jpeg'),
    
    -- Maschere
    (6, 'Maschera BioUnisa', 'La maschera per il viso al gusto di fragola BioUnisa è una delizia per i sensi e una festa per la pelle, arricchita con estratti di fragola ricchi di vitamine e antiossidanti. <br>
	Questa formula indulgente riduce l’aspetto dei pori, illumina il viso spento e leviga la texture della pelle, lasciandola morbida, levigata e radiosa. <br>
	Con la sua fragranza irresistibile e la sua consistenza cremosa, questa maschera trasforma la vostra routine di bellezza in un momento di puro piacere e coccole. <br>
	Il trattamento indulgente che renderà la vostra pelle fresca, luminosa e deliziosamente profumata. <br>
	<b> Formulazione: </b>Ecobio <br>
	<b> pH: </b>Fisiologico <br> ', 'Maschere', '50 ml', 26.99, 300, 'Immagini/Maschera.jpeg'),
    
    -- Protezione solare
    (7, 'Protezione Solare BioUnisa', 'La protezione solare BioUnisa è una fusione di scienza e natura, formulata con ingredienti di alta qualità per offrire una protezione efficace e delicata. <br>
	Con filtri solari ad ampio spettro e ingredienti antiossidanti, la nostra formula protegge la pelle dai danni dei raggi UVA e UVB, prevenendo l’invecchiamento precoce e le macchie solari, mentre idrata e nutre in profondità. <br>
	La sua texture leggera e non appiccicosa si assorbe istantaneamente, garantendo una protezione confortevole e duratura per tutta la giornata. <br>
	La protezione solare BioUnisa rappresenta il vostro alleato per mantenere la pelle sana e splendente, ovunque vi porti il sole. <br>
	<b> Formulazione: </b>Ecobio <br>
	<b> pH: </b>Fisiologico <br>', 'Protezione solare', '35 ml', 10.99, 150, 'Immagini/protezionesolare.jpeg'),
    
    -- Esfolianti
    (9, 'Esfoliante BioUnisa', 'L’esfoliante viso BioUnisa è una sinfonia di ingredienti naturali e formulazioni innovative, progettati per esfoliare delicatamente la pelle senza irritarla. <br>
	Con granuli esfolianti finemente macinati e arricchiti con estratti botanici rigeneranti, questo trattamento esfoliante leviga la texture della pelle, riduce i pori dilatati e promuove il rinnovamento cellulare, lasciando la pelle visibilmente più luminosa e uniforme. <br>
	Ogni utilizzo è un’esperienza sensoriale unica, che vi avvolge in una sensazione di freschezza e benessere. <br>
	<b> Formulazione:</b>Ecobio <br>
	<b> pH:</b> Fisiologico <br>', 'Esfolianti', '50 ml', 15.00, 250, 'Immagini/esfoliante.jpeg'),
    
    -- Toner e acque floreali
    (10, 'Toner Floreale BioUnisa', 'L’acqua floreale BioUnisa è una sinfonia di petali di fiori freschi e ingredienti botanici, raccolti con cura per preservare la loro essenza naturale e i benefici per la pelle. <br>
 	Arricchita con estratti di fiori rigeneranti e acque distillate, questa formula delicata lenisce la pelle irritata, rinfresca i sensi e prepara la pelle per l’idratazione successiva. <br>
	La sua texture leggera e non grassa la rende ideale per tutti i tipi di pelle, donando un’immediata sensazione di comfort e benessere. <br>
	L’acqua floreale BioUnisa rappresenta per voi un tocco di freschezza e bellezza che vi accompagnerà in ogni momento della giornata. <br>
	<b> Formulazione:</b> Ecobio <br>
 	<b> pH:</b> Fisiologico <br>', 'Toner e acque floreali', '100 ml', 17.99, 120, 'Immagini/TonerEAcqueFloreali.jpeg'),
    
    -- Oli Viso
    (11, 'Olio Viso BioUnisa', 'La formula dell’olio BioUnisa  è una sinfonia di oli pregiati, selezionati per le loro proprietà  rigeneranti e nutrienti. <br>
	Con una miscela di oli vegetali ricchi di antiossidanti, acidi grassi essenziali e vitamine, il nostro olio viso nutre in profondità  la pelle, riducendo la secchezza, migliorando l’elasticità  e proteggendo dai danni ambientali. <br>
	Concedetevi il lusso di una pelle luminosa e radiosa con il nostro olio viso, il tocco finale perfetto per una routine di bellezza completa e una pelle visibilmente trasformata e radiante. <br>
	<b> Formulazione: </b>Ecobio <br>
    <b> pH:</b> Fisiologico <br>', 'Oli Viso', '30 ml', 18.99, 180, 'Immagini/Oliviso.jpeg'),
    
    -- Trattamenti anti-età
    (12, 'Trattamento Anti-età BioUnisa', 'Il trattamento anti-età BioUnisa è formulato con ingredienti studiati per rigenerare la pelle dall’interno verso l’esterno. <br>
	Questa formula combatte le rughe, leviga la texture della pelle e dona un aspetto più giovane e radioso. <br> 
	Lasciatevi avvolgere dalla sua texture lussuosa e dalla sua fragranza delicata, mentre ogni applicazione vi avvicina sempre di più alla pelle dei vostri sogni. <br>
	<b> Formulazione: </b>Ecobio <br>
	<b> pH: </b> Fisiologico <br> ', 'Trattamenti anti-età', '50 ml', 26.99, 300, 'Immagini/Trattamentianti-età.jpeg'),
    
    -- Make-up naturale
    (13, 'Mascara BioUnisa', 'Il mascara BioUnisa è formulato con ingredienti naturali e biologici per ridurre l’impatto sulla pelle e sull’ambiente. <br>
	La nostra formula leggera e priva di grumi avvolge ogni ciglia con un colore intenso e vibrante, garantendo un effetto a lunga tenuta senza sbavature. <br>
	Arricchito con ingredienti idratanti e nutrienti, come l’olio di argan e la vitamina E, il nostro mascara non solo valorizza le tue ciglia, ma le nutre e le protegge durante tutto il giorno. <br>
	La spazzola dalla forma ergonomica cattura ogni singola ciglia dalla radice alla punta, permettendo una facile applicazione e un risultato uniforme senza grumi. <br>
	Dalle giornate dinamiche in ufficio alle serate glamour, il nostro mascara BioUnisa è il compagno ideale per esaltare la bellezza naturale dei tuoi occhi. <br>
	<b> Formulazione: </b> Ecobio  <br>
	<b> pH: </b>Fisiologico <br>', 'Make-up naturale', '10 ml', 23.60, 100, 'Immagini/Mascara.jpeg'),
    
    -- Accessori per la cura della pelle
    (14, 'Accessori per la Cura della Pelle', 'Lasciatevi trasportare dalla delicatezza del set BioUnisa composto da: <br>
 	-un rullo progettato per massaggiare delicatamente il viso e ridurre il gonfiore, mentre stimola la circolazione per una pelle luminosa e radiosa; <br>
	-un pennello per maschere, con setole morbide e resistenti, è  l’accessorio perfetto per applicare le vostre maschere preferite con precisione e uniformità, garantendo risultati ottimali ad ogni utilizzo.  <br>
 	Ogni accessorio è stato selezionato con cura per offrire un tocco di lusso e una performance impeccabile, trasformando la vostra routine di cura della pelle in un momento di puro piacere e indulgenza. <br>
	<b> Formulazione: </b>Ecobio <br>
	<b> pH: </b> fisiologico <br>', 'Accessori per la cura della pelle', 'Non specificato', 20.00, 150, 'Immagini/AccessoriPerLaPelle.jpeg');


-- Rimuove la tabella utente se esiste già
DROP TABLE IF EXISTS utente;
-- Crea la tabella utente
CREATE TABLE utente (
    idUtente INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefono VARCHAR(15) NOT NULL,
    nuovoRecapito VARCHAR(15) NULL,
    indirizzo VARCHAR(255) NOT NULL,
    citta VARCHAR(50) NOT NULL,
    provincia VARCHAR(50) NOT NULL,
    cap VARCHAR(10) NOT NULL,
    stato VARCHAR(20) CHECK (stato IN ('Registrato', 'Non registrato', 'Amministratore')) NOT NULL,
    profileImagePath VARCHAR(255) NULL
);
-- POPOLAMENTO TABELLA UTENTE
INSERT INTO utente (username, password, nome, cognome, email, telefono, nuovoRecapito, indirizzo, citta, provincia, cap, stato, profileImagePath)
VALUES
    -- password dell'amministratore è Lucia00!
    ('root@gmail.com', '4eaa2207579ae2692ddc409d8bc13e5791acecfb9b21954e3d45986991355c12482c854ffbc9f663035a6bef8cbd15a373244d62748754f40e019d9b39ee266e', 'Admin', 'Admin', 'root@gmail.com', '1234567890', '', 'via università ', 'Fisciano', 'Sa', '12345', 'Amministratore', NULL),
    -- password di Luigi è Luigi1214!
    ('luigi@gmail.com', '45012abe6e9c28446f090d1d7d0cfdb588c4a05aa560c4c2d525e0e13f3acec816dbb4547dd583206a3045a8d2f33a2e205d4019e3043413251ada4485d2a658', 'Luigi', 'Russo', 'luigi@gmail.com', '0987654321', '', 'Via giacomo leopardi', 'Marigliano', 'NA', '12345', 'Registrato', 'Fotoprofilo/luigi.jpg'),
    -- password di Stella è Stella1214!
    ('stella@gmail.com', 'fcdbc806b198c1d65babb6226d05bfcdbb4044708d12f18af981810b951fd469c2a2f6338fb8a4134731e6024fe9a87fbfc0e707d56805fb8f8bae33c1420032', 'Stella', 'Tavolo', 'stella@gmail.com', '9876543210', '', 'Via giacomo matteotti','Marigliano', 'NA', '12345', 'Registrato', 'Fotoprofilo/stella.jpeg'),
    -- password di Lucia è Lucia1214!
    ('lucia@gmail.com', '825ebe870b0ba3acc10070f715e47f9fc702039499cea2e3f3f30bfe44164535de01e2afbbd4800dd2ccc022eb3e82809e5b83501d59a3a8747435a0366c06bd', 'Lucia', 'Ferrara', 'lucia@gmail.com', '0123456789', '', 'Via luigi palumbo', 'Cava Dei Tirreni', 'SA', '84013', 'Registrato', 'Fotoprofilo/lucia.jpeg'),
    -- password di Pasquale è Pasquale1214!
    ('pasquale@gmail.com', '00fd96926a23ffce9079f40a622a6884da63a93544b71b6de56235351a069d993a2256e90be0f7ab8511c8cb5da68ac8b644f1348bf8ec2719a6ced71bfc2418', 'Pasquale', 'Ferrara', 'pasquale@gmail.com', '1234509876', '', 'Via francesco tavolo', 'Cava Dei Tirreni', 'SA', '84013', 'Registrato', 'Fotoprofilo/pasquale.jpeg'),
    -- password di Rosalba è Rosalba1214!
    ('rosalba@gmail.com', '7ed8cb5b363a9588c1aadde1cd4e4283e1bc31a7783b8ce6736429dcad58cd6964360e7a518c6f2ac54a684f5304090331430ea62453fadac9ae134e885b3650', 'Rosalba', 'Addeo', 'rosalba@gmail.com', '0987601234', '', 'Via marteri della resistenza', 'Marigliano', 'NA','12345', 'Registrato', 'Fotoprofilo/rosalba.jpeg'),
    -- password di Giuseppe è Giuseppe1214!
    ('giuseppe@gmail.com', '62500234a796d7f7a5db9b9c66072f7c4ee7be318372c9aad1e45c9c97c28b2c836bf381ea99836e3ffa6fec0bf2b9888f5fbee8fa1a17d30e9e9c5807b5bc6e', 'Giuseppe', 'Russo', 'giuseppe@gmail.com', '1234987650', '', 'Via nocera ferrara', 'Marigliano', 'NA', '12345', 'Registrato', 'Fotoprofilo/giuseppe.jpg'),
    -- password di Giuseppina è Giuseppina1214!
    ('giuseppina@gmail.com', 'ffde9b63f91fe1da8258f1e5af4a1d58e2968979653e3d5e9318a69d2b8c4eb9137083909a0dca8c8913dfaa450b34207309ccceac3a582fe5ffb3a2e818496c', 'Giuseppina', 'Sapio', 'giuseppina@gmail.com', '5678901234', '', 'Via giovanni bosco', 'Marigliano', 'NA', '12345', 'Registrato', 'Fotoprofilo/giuseppina.jpeg'),
    -- password di Antonio è Antonio1214!
    ('antonio@gmail.com', 'a9a67f94fc727d5e89bf77870d2867240b9e9adcadbc9213363a13fa88dff3baec73fe4a6305c530e89e05790150fd866092992e90ca655fd0f52aea92e89de9', 'Antonio', 'Russo', 'antonio@gmail.com', '0987654321', '', 'Via sabato longobardi', 'Marigliano', 'NA', '12345', 'Registrato', 'Fotoprofilo/antonio.jpeg'),
    -- password di Patrizia è Patrizia1214!
    ('patrizia@gmail.com', '958a91b3f6c4e918ded2d0dfd37d2c2944ba7f8808c4e4692b61ad26acc6c519fbda3add21d2f4e967695ca60b283be6643f05722d18b6b039876b40f49f36b4', 'Patrizia', 'Masullo', 'patrizia@gmail.com', '5678904321', '', 'Via isonzo','Cava Dei Tirreni', 'SA','84013', 'Registrato', 'Fotoprofilo/patrizia.jpeg'),
    -- password di Felice è Felice1214!
    ('felice@gmail.com', '2329275a40502d08ef3e6258ba18a60d315184bfe4cc2cbca789b471f9adace3e39822f9e0f0593a076e2b81169c89c65ab1d5abf19400a836501d12afb8da70', 'Felice', 'Ferrara', 'felice@gmail.com', '3456789012', '', 'Via manfredi', 'Cava Dei Tirreni', 'SA', '84013', 'Registrato', 'Fotoprofilo/felice.jpeg'),
    -- password di Tina è Tina1214!
    ('tina@gmail.com', '35cedb254e99b7efea6375761f38533d557a8d96e6013dc9ba8c43a7aef05dabb52e392be3d2fdda2d175fdffb5dd84da35cdcda2e4ad1bf7cc613107d7a27c3', 'Tina', 'Boffardi', 'tina@gmail.com', '2345678901', '', 'Via gambardella ', 'Cava Dei Tirreni', 'SA', '84013', 'Registrato', 'Fotoprofilo/tina.jpeg'),
    -- password di Alessia è Alessia1214!
    ('alessia@gmail.com', '4e022dcac413fbc46960124f90b657773964b519980af0656d844ac905be9afea177bd2c2f1105729c439fd0560eed63be8758e6dfc7e712125868ce7f48b52f', 'Alessia', 'Gatto', 'alessia@gmail.com', '1234567890', '', 'Via chiaia', 'Paestum', 'SA', '84013', 'Registrato', 'Fotoprofilo/alessia.jpeg');

-- Rimuove la tabella carrello se esiste già
DROP TABLE IF EXISTS carrello;
-- Crea la tabella carrello
CREATE TABLE carrello (
    IDCarrello INT PRIMARY KEY,
    Quantità  INT NOT NULL
);
-- POPOLAMENTO TABELLA CARRELLO 
INSERT INTO carrello (IDCarrello, Quantità )
VALUES
    ('7778', '5'),
    ('1596', '7'),
    ('3264', '10');


-- Rimuove la tabella ordine se esiste già
DROP TABLE IF EXISTS ordine;
-- Crea la tabella ordine
CREATE TABLE ordine (
    idOrdine INT PRIMARY KEY AUTO_INCREMENT,
    dataOrdine DATE NOT NULL,
    oraOrdine TIME NOT NULL,
    totaleOrdine DECIMAL(10, 2) NOT NULL,
    quantità INT NOT NULL,
    statoOrdine VARCHAR(50) CHECK (statoOrdine IN ('In attesa di conferma', 'In elaborazione', 'In transito', 'Consegnato', 'Annullato', 'Rimborsato', 'In attesa di pagamento')) NOT NULL,
    userId INT NOT NULL,
    FOREIGN KEY (userId) REFERENCES utente(idUtente) 
);
-- Popolamento della tabella ordine
INSERT INTO ordine (dataOrdine, oraOrdine, totaleOrdine, quantità, statoOrdine, userId)
VALUES
    ('2007-06-29', '11:06:00', 80.00, 18, 'In elaborazione', (SELECT idUtente FROM utente WHERE username = 'luigi@gmail.com')),
    ('2007-08-24', '11:54:00', 75.00, 15, 'In transito', (SELECT idUtente FROM utente WHERE username = 'stella@gmail.com')),
    ('2001-03-26', '17:06:00', 40.00, 23, 'In attesa di conferma', (SELECT idUtente FROM utente WHERE username = 'lucia@gmail.com')),
    ('2004-04-30', '11:06:00', 45.00, 21, 'Consegnato', (SELECT idUtente FROM utente WHERE username = 'pasquale@gmail.com')),
    ('2012-12-10', '12:45:00', 105.50, 33, 'In attesa di pagamento', (SELECT idUtente FROM utente WHERE username = 'luigi@gmail.com')),
    ('2000-09-25', '11:14:00', 120.00, 20, 'Rimborsato', (SELECT idUtente FROM utente WHERE username = 'stella@gmail.com'));



-- Rimuove la tabella fattura se esiste già
DROP TABLE IF EXISTS fattura;
-- Crea la tabella fattura
CREATE TABLE fattura (
    idFattura INT PRIMARY KEY AUTO_INCREMENT,
    dataFattura DATE NOT NULL,
    importo DECIMAL(10, 2) NOT NULL,
    idOrdine INT NOT NULL,
    FOREIGN KEY (idOrdine) REFERENCES ordine(idOrdine) ON DELETE CASCADE
);
-- POPOLAMENTO TABELLA FATTURA
INSERT INTO fattura (dataFattura, importo, idOrdine)
VALUES
    ('2004-07-04', 48.50, 1),
    ('2007-06-30', 80.00, 2),
    ('2007-08-25', 75.00, 3),
    ('2001-03-27', 40.00, 4),
    ('2004-05-01', 45.00, 5),
    ('2002-07-10', 95.00, 6);



-- Rimuove la tabella preferiti se esiste già
DROP TABLE IF EXISTS preferiti;
-- Crea la tabella preferiti
CREATE TABLE preferiti (
    idPreferiti INT PRIMARY KEY AUTO_INCREMENT,
    idUtente INT NOT NULL,
    idProdotto INT NOT NULL,
    FOREIGN KEY (idUtente) REFERENCES utente(idUtente),
    FOREIGN KEY (idProdotto) REFERENCES prodotto(idProdotto)
);
-- POPOLAMENTO TABELLA PREFERITI
INSERT INTO preferiti (idUtente, idProdotto)
VALUES
    ((SELECT idUtente FROM utente WHERE username = 'root@gmail.com'), 2),
    ((SELECT idUtente FROM utente WHERE username = 'luigi@gmail.com'), 4),
    ((SELECT idUtente FROM utente WHERE username = 'stella@gmail.com'), 7),
    ((SELECT idUtente FROM utente WHERE username = 'lucia@gmail.com'), 6);



-- Tabella Associazione Contiene (Prodotto e Carrello)
-- Rimuove la tabella contiene se esiste già
DROP TABLE IF EXISTS contiene;
-- Crea la tabella contiene
CREATE TABLE contiene (
    IDCarrello INT NOT NULL, 
    idProdotto INT NOT NULL,
    Quantità INT NOT NULL,
    PRIMARY KEY (IDCarrello, idProdotto),
    FOREIGN KEY (IDCarrello) REFERENCES carrello(IDCarrello),
    FOREIGN KEY (idProdotto) REFERENCES prodotto(idProdotto) ON DELETE CASCADE
);
-- POPOLAMENTO TABELLA CONTIENE
INSERT INTO contiene (IDCarrello, idProdotto, Quantità) VALUES
    ('1596', '2', 13),
    ('1596', '5', 17),
    ('3264', '4', 45),
    ('7778', '7', 9),
    ('7778', '9', 4)
    ON DUPLICATE KEY UPDATE Quantità = Quantità + VALUES(Quantità);


-- Tabella Associazione Comprende (Prodotto e Ordine)
-- Rimuove la tabella comprende se esiste già
DROP TABLE IF EXISTS comprende;
-- Crea la tabella comprende
CREATE TABLE comprende (
	Prezzo DECIMAL(10, 2) NOT NULL,
    Iva DECIMAL(5, 2) NOT NULL,
    quantità INT NOT NULL,
	idOrdine INT NOT NULL, 
    idProdotto INT NOT NULL,
    PRIMARY KEY (idOrdine, idProdotto),
    FOREIGN KEY (idOrdine) REFERENCES ordine(idOrdine),
    FOREIGN KEY (idProdotto) REFERENCES prodotto(idProdotto) ON DELETE CASCADE
);
-- POPOLAMENTO TABELLA COMPRENDE
INSERT INTO comprende (Prezzo, Iva, quantità, idOrdine, idProdotto) VALUES
    ('19.99','22',45,'1', '2'),
    ('25.00','22',12,'2', '4'),
    ('21.99','22',23,'3', '5'),
    ('26.99','22',19,'4', '6'),
    ('10.99','22',23,'5', '7'),
    ('15.99','22',10,'6', '9');


-- Crea la tabella recensione
CREATE TABLE recensisce (
    Valutazione INT NOT NULL CHECK (Valutazione >= 0 AND Valutazione <= 5),
    TestoRecensione VARCHAR(500) NOT NULL,
    DataRecensione DATE NOT NULL,
    OraRecensione TIME NOT NULL,
    idProdotto INT NOT NULL,
    idUtente INT NOT NULL,
    FOREIGN KEY (idUtente) REFERENCES utente(idUtente) ON DELETE CASCADE,
    FOREIGN KEY (idProdotto) REFERENCES prodotto(idProdotto) ON DELETE CASCADE,
    UNIQUE (idUtente, idProdotto)  -- Assicura che ogni utente possa recensire uno specifico prodotto solo una volta
);
-- POPOLAMENTO TABELLA RECENSIONE
INSERT INTO recensisce (Valutazione, TestoRecensione, DataRecensione, OraRecensione, idProdotto, idUtente)
VALUES 
    (5, 'Da quando ho iniziato ad utilizzare i prodotti BioUnisa, la mia pelle non è mai stata così radiosa! La crema idratante è diventata un must della mia beauty routine quotidiana.', '2024-06-14', '10:00', 2, (SELECT idUtente FROM utente WHERE username = 'luigi@gmail.com')),
    (4, 'BioUnisa è molto più di una semplice linea di prodotti per la cura della pelle; è un viaggio verso la bellezza naturale e il benessere interiore. La dedizione delle fondatrici traspare in ogni dettaglio, dalla selezione degli ingredienti alla presentazione dei prodotti. Consiglio BioUnisa a tutti coloro che desiderano una routine di bellezza autentica e rispettosa della pelle.', '2024-06-14', '10:00', 4, (SELECT idUtente FROM utente WHERE username = 'pasquale@gmail.com')),
    (5, 'Sono rimasta colpita dall\'impatto positivo dei prodotti BioUnisa sulla mia pelle sensibile. Finalmente ho trovato una gamma di prodotti che non solo non irrita la mia pelle, ma la rende davvero luminosa e radiosa. Non potrei essere più soddisfatta!', '2024-06-14', '10:00', 5, (SELECT idUtente FROM utente WHERE username = 'rosalba@gmail.com')),
    (5, 'BioUnisa è diventato il mio brand di fiducia per la cura della pelle. Ogni prodotto è un piccolo rituale di benessere che non posso fare a meno di includere nella mia routine quotidiana.', '2024-06-14', '10:00', 6, (SELECT idUtente FROM utente WHERE username = 'giuseppe@gmail.com')),
    (5, 'BioUnisa è diventato il mio rituale di bellezza quotidiano. Ogni mattina, applico con piacere il loro siero idratante, sapendo di prendere cura della mia pelle in modo sano e naturale. Grazie per aver creato prodotti così eccezionali!', '2024-06-14', '10:00', 7, (SELECT idUtente FROM utente WHERE username = 'giuseppina@gmail.com')),
    (5, 'Sono rimasto piacevolmente sorpreso dalla qualità dei prodotti BioUnisa. La mia pelle sensibile finalmente ha trovato la sua soluzione ideale. Consigliatissimi!', '2024-06-14', '10:00', 9, (SELECT idUtente FROM utente WHERE username = 'patrizia@gmail.com')),
    (5, 'Ho provato diversi prodotti per la cura della pelle nel corso degli anni, ma nessuno ha mai superato l\'efficacia e la delicatezza delle formulazioni BioUnisa. Sono veramente entusiasta dei risultati!', '2024-06-14', '10:00', 10, (SELECT idUtente FROM utente WHERE username = 'felice@gmail.com')),
    (5, 'Le profumazioni delicate e naturali dei prodotti BioUnisa rendono l\'applicazione un vero piacere per i sensi. Oltre alla bellezza della pelle, regalano anche momenti di relax e coccole per l\'anima.', '2024-06-14', '10:00', 11, (SELECT idUtente FROM utente WHERE username = 'alessia@gmail.com')),
    (4, 'Sono rimasta affascinata dalla filosofia dietro il marchio BioUnisa. La combinazione di ingredienti naturali e la passione delle fondatrici per la cura della pelle si riflette chiaramente nella qualità dei loro prodotti. Un\'esperienza di bellezza davvero unica!', '2024-06-14', '10:00', 12, (SELECT idUtente FROM utente WHERE username = 'antonio@gmail.com')),
    (5, 'Da quando ho iniziato ad utilizzare la crema notte di BioUnisa, ho notato un miglioramento significativo nella texture e nell\'elasticità della mia pelle. Non posso più fare a meno di questo prodotto nella mia routine serale!', '2024-06-14', '10:00', 13, (SELECT idUtente FROM utente WHERE username = 'tina@gmail.com'));