package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.unisa.model.AcquistaBean;
import it.unisa.model.AcquistaModel;
import it.unisa.model.AcquistaModelDM;

@WebServlet("/acquistaControl")
public class AcquistaControl extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Indica che utilizza il DataSource per la connessione al database
    static boolean isDataSource = true;

    // Inizializza il modello per gestire i dati di acquisto
    static AcquistaModel Model = new AcquistaModelDM();

    // Costruttore della servlet
    public AcquistaControl() {
        super();
    }

    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    //Metodo doGet, che gestisce le richieste GET,non necessario in questa servlet
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Risponde con un errore 405 (Metodo non permesso)
        response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "GET method is not supported.");
    }

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    // Metodo doPost, che gestisce le richieste POST, cio� che elabora i dati inviati da un modulo (data, ora, ID utente, ID prodotto) e li salva nel database
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupero dei parametri dalla richiesta
        String dataAcquistoStr = request.getParameter("dataAcquisto");
        String oraAcquistoStr = request.getParameter("oraAcquisto");
        String idUtenteStr = request.getParameter("idUtente");
        String idProdottoStr = request.getParameter("idProdotto");

        try {
            // Conversione della stringa della data in oggetto Date
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date dataAcquisto = new Date(dateFormat.parse(dataAcquistoStr).getTime());

            // Conversione della stringa dell'ora in oggetto Time
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
            Time oraAcquisto = new Time(timeFormat.parse(oraAcquistoStr).getTime());

            // Conversione delle stringhe degli ID utente e prodotto in interi
            int idUtente = Integer.parseInt(idUtenteStr);
            int idProdotto = Integer.parseInt(idProdottoStr);

            // Creazione di un nuovo oggetto AcquistaBean e impostazione dei suoi attributi
            AcquistaBean acquista = new AcquistaBean();
            acquista.setdataAcquisto(dataAcquisto);
            acquista.setoraAcquisto(oraAcquisto);
            acquista.setidUtente(idUtente);
            acquista.setidProdotto(idProdotto);

            try {
                // Salvataggio dei dati dell'acquisto nel database
                Model.doSave(acquista);
                // Inserimento riuscito, reindirizza alla pagina di successo
                response.sendRedirect(request.getContextPath() + "/successo.jsp");
            } catch (SQLException e) {
                // Gestione dell'errore SQL
                e.printStackTrace();
                // Reindirizza alla pagina di errore 500 (errore interno del server)
                response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
            }
        } catch (ParseException e) {
            // Gestione dell'errore di parsing della data (se la conversione fallisce)
            e.printStackTrace();
            // Reindirizza alla pagina di errore 400 (richiesta non valida)
            response.sendRedirect(request.getContextPath() + "/errore/Errore400.jsp");
        } catch (NumberFormatException e) {
            // Gestione dell'errore di parsing dei numeri (se la conversione fallisce)
            e.printStackTrace();
            // Reindirizza alla pagina di errore 400 (richiesta non valida)
            response.sendRedirect(request.getContextPath() + "/errore/Errore400.jsp");
        }
    }
}
