package it.unisa.control;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter("/AuthFilter")
public class AuthFilter implements Filter {

    // Metodo chiamato durante la distruzione del filtro
    public void destroy() {
    }

    // Metodo principale del filtro, chiamato per ogni richiesta che passa attraverso il filtro
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        // Conversione delle richieste e risposte generiche a tipi specifici HTTP
    	HttpServletRequest hrequest = (HttpServletRequest) request;
        HttpServletResponse hresponse = (HttpServletResponse) response;
        
        // URI della pagina di login per gli amministratori
        String loginUri = hrequest.getContextPath() + "/adminFilter";
        // Verifica se la richiesta � per l'URI di login amministrativo
        boolean loginRequest = hrequest.getRequestURI().startsWith(loginUri);
        
        if (loginRequest) {
            // Controlla il ruolo dell'utente dalla sessione
            HttpSession session = hrequest.getSession(false);
            boolean loggedIn = session != null && "Amministratore".equals(session.getAttribute("stato"));

            if (!loggedIn) {
                // Se l'utente non � loggato come amministratore, reindirizza al modulo di accesso
                hresponse.sendRedirect(hrequest.getContextPath() + "/login-form-filter.jsp");
            } else {
                // Se l'utente � loggato come amministratore, permette l'accesso alla risorsa
                chain.doFilter(request, response);
            }
        } else {
            // Se la richiesta non � per una risorsa amministrativa, permette l'accesso alla risorsa
            chain.doFilter(request, response);
        }
    }

    // Metodo chiamato durante l'inizializzazione del filtro
    public void init(FilterConfig fConfig) throws ServletException {
    }
}
