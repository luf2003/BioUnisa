package it.unisa.control;

import it.unisa.model.ProdottoModelDM;
import it.unisa.model.ProdottoBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.Collection;

@WebServlet("/catalogoAdminServlet")
//Annotazione per gestire i file upload multiparte
@MultipartConfig
public class CatalogoAdminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recupera l'azione richiesta
    	String action = request.getParameter("action");
        ProdottoModelDM model = new ProdottoModelDM();

        // Controllo per gestire l'inserimento di un nuovo prodotto
        if ("inserisci".equals(action)) {
            // Recupero dei parametri del prodotto dalla richiesta
        	String nome = request.getParameter("nomeProdotto");
            String descrizione = request.getParameter("descrizioneProdotto");
            double prezzo = Double.parseDouble(request.getParameter("prezzoProdotto"));
            int quantita = Integer.parseInt(request.getParameter("quantitaProdotto"));
            String categoria = request.getParameter("categoriaProdotto");
            String formato = request.getParameter("formatoProdotto");

            // Gestisce l'upload dell'immagine del prodotto
            Part filePart = request.getPart("percorsoimmagine");
            String percorsoimmagine = "";
            if (filePart != null && filePart.getSize() > 0) {
                String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                String uploadPath = getServletContext().getRealPath("/") + "Immagini";
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdir();
                }
                String filePath = uploadPath + File.separator + fileName;
                try (InputStream input = filePart.getInputStream()) {
                    Files.copy(input, Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
                    percorsoimmagine = "Immagini/" + fileName;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            // Crea un nuovo ProdottoBean e imposta i suoi attributi
            ProdottoBean prodotto = new ProdottoBean();
            prodotto.setnome(nome);
            prodotto.setdescrizione(descrizione);
            prodotto.setprezzoUnitario(prezzo);
            prodotto.setquantitaDisponibile(quantita);
            prodotto.setpercorsoimmagine(percorsoimmagine);
            prodotto.setcategoria(categoria);
            prodotto.setformato(formato);

            // Salva il nuovo prodotto nel database

            try {
                model.doSave(prodotto);
                request.getSession().setAttribute("successMessage", "Prodotto inserito con successo.");
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Aggiorna la lista dei prodotti nella sessione
            try {
                Collection<ProdottoBean> prodotti = model.doRetrieveAll(null);
                request.getSession().setAttribute("prodotti", prodotti);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            // Reindirizza alla pagina dell'admin
            request.getRequestDispatcher("/admin/House.jsp").forward(request, response);

            // Mostra la pagina di inserimento del prodotto
        } else if ("mostraInserimento".equals(action)) {
            request.getRequestDispatcher("/admin/InserisciProdotto.jsp").forward(request, response);
            // Gestione della modifica di un prodotto esistente
        } else if ("modifica".equals(action)) {
            // Recupera i parametri del prodotto dalla richiesta
        	int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));
            String nome = request.getParameter("nomeProdotto");
            String descrizione = request.getParameter("descrizioneProdotto");
            double prezzo = Double.parseDouble(request.getParameter("prezzoProdotto"));
            int quantita = Integer.parseInt(request.getParameter("quantitaProdotto"));
            String categoria = request.getParameter("categoriaProdotto");
            String formato = request.getParameter("formatoProdotto");
            Part filePart = request.getPart("percorsoimmagine");
            String percorsoimmagine = request.getParameter("existingImage");
            if (filePart != null && filePart.getSize() > 0) {
                String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                String uploadPath = getServletContext().getRealPath("/") + "Immagini";
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdir();
                }
                String filePath = uploadPath + File.separator + fileName;
                try (InputStream input = filePart.getInputStream()) {
                    Files.copy(input, Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
                    percorsoimmagine = "Immagini/" + fileName;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            
            // Crea un nuovo ProdottoBean e imposta i suoi attributi
            ProdottoBean prodotto = new ProdottoBean();
            prodotto.setidProdotto(idProdotto);
            prodotto.setnome(nome);
            prodotto.setdescrizione(descrizione);
            prodotto.setprezzoUnitario(prezzo);
            prodotto.setquantitaDisponibile(quantita);
            prodotto.setpercorsoimmagine(percorsoimmagine);
            prodotto.setcategoria(categoria);
            prodotto.setformato(formato);

            // Aggiorna il prodotto nel database
            try {
                model.doUpdate(prodotto);
                request.getSession().setAttribute("successMessage", "Prodotto modificato con successo.");
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Reindirizza alla pagina House 
            request.getRequestDispatcher("/admin/House.jsp").forward(request, response);

            // Gestione della cancellazione di un prodotto esistente
        } else if ("cancella".equals(action)) {
            int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));

            // Cancella il prodotto dal database
            try {
                model.doDelete(idProdotto);
                request.getSession().setAttribute("successMessage", "Prodotto cancellato con successo.");
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Aggiorna la lista dei prodotti nella sessione
            try {
                Collection<ProdottoBean> prodotti = model.doRetrieveAll(null);
                request.getSession().setAttribute("prodotti", prodotti);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            // Reindirizza alla pagina House
            request.getRequestDispatcher("/admin/House.jsp").forward(request, response);
        } else {
            // Aggiornamento della lista dei prodotti nella sessione
            try {
                Collection<ProdottoBean> prodotti = model.doRetrieveAll(null);
                request.getSession().setAttribute("prodotti", prodotti);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            // Reindirizza alla pagina House
            request.getRequestDispatcher("/admin/House.jsp").forward(request, response);
        }
    }

    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recupera l'azione richiesta
    	String action = request.getParameter("action");
        if ("mostraModifica".equals(action)) {
            // Mostra la pagina di modifica del prodotto
        	int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));
            ProdottoModelDM model = new ProdottoModelDM();
            try {
                ProdottoBean prodotto = model.doRetrieveByKey(idProdotto);
                request.setAttribute("prodotto", prodotto);
                request.getRequestDispatcher("/admin/ModificaProdotto.jsp").forward(request, response);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            // Se l'azione non � specificata, delega la richiesta al metodo doPost
            doPost(request, response);
        }
    }
}
