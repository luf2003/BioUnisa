package it.unisa.control;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Collection;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.unisa.model.ComprendeBean;
import it.unisa.model.ComprendeModel;
import it.unisa.model.ComprendeModelDM;

public class ComprendeControl extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Modello per gestire le operazioni sui dati di Comprende
    static ComprendeModel Model = new ComprendeModelDM();

    // Costruttore della servlet
    public ComprendeControl() {
        super();
    }
    
    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera l'azione richiesta
    	String action = request.getParameter("action");

        try {
            // Se l'azione � "view", mostra i dettagli dell'ordine
            if (action != null && action.equalsIgnoreCase("view")) {
                int idOrdine = Integer.parseInt(request.getParameter("idOrdine"));
                // Recupera i dettagli dell'ordine dal modello
                Collection<ComprendeBean> dettagliOrdine = Model.doRetrieveByOrdine(idOrdine);
                // Imposta i dettagli dell'ordine come attributo della richiesta
                request.setAttribute("dettagliOrdine", dettagliOrdine);
                // Inoltra la richiesta alla pagina JSP per visualizzare i dettagli dell'ordine
                RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/both/dettagliOrdine.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            // Gestione delle eccezioni SQL
            e.printStackTrace();
            // Reindirizza alla pagina di errore 500 (errore interno del server)
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
        }
    }

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera i parametri dalla richiesta
    	String idOrdineStr = request.getParameter("idOrdine");
        String idProdottoStr = request.getParameter("idProdotto");
        String quantitaStr = request.getParameter("quantita");
        String prezzoStr = request.getParameter("prezzo");
        String ivaStr = request.getParameter("iva");

        // Conversione dei parametri ai tipi di dato appropriati
        int idOrdine = Integer.parseInt(idOrdineStr);
        int idProdotto = Integer.parseInt(idProdottoStr);
        int quantita = Integer.parseInt(quantitaStr);
        double prezzo = Double.parseDouble(prezzoStr);
        BigDecimal iva = new BigDecimal(ivaStr);

        // Creazione di un nuovo ComprendeBean e impostazione dei suoi attributi
        ComprendeBean comprende = new ComprendeBean();
        comprende.setidOrdine(idOrdine);
        comprende.setidProdotto(idProdotto);
        comprende.setquantit�(quantita);
        comprende.setprezzo(prezzo);
        comprende.setIva(iva);

        try {
            // Salva i dati del ComprendeBean nel database
            Model.doSave(comprende);
            // Reindirizza alla pagina di successo
            response.sendRedirect(request.getContextPath() + "/both/successo.jsp");
        } catch (SQLException e) {
            // Gestione delle eccezioni SQL
            e.printStackTrace();
            // Reindirizza alla pagina di errore 500 (errore interno del server)
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
        }
    }
}
