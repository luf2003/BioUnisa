package it.unisa.control;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.List;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import it.unisa.model.Carrello;
import it.unisa.model.OrdineBean;
import it.unisa.model.OrdineModel;
import it.unisa.model.OrdineModelDM;
import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModelDM;
import it.unisa.model.ComprendeBean;
import it.unisa.model.ComprendeModelDM;
import java.util.Collection;

@WebServlet("/ConfermaOrdine")
public class ConfermaOrdine extends HttpServlet {
    private static final long serialVersionUID = 1L;
    // Modelli per gestire le operazioni sui dati degli ordini, prodotti e dettagli degli ordini
    private OrdineModel ordineModel = new OrdineModelDM();
    private ComprendeModelDM comprendeModel = new ComprendeModelDM();
    private ProdottoModelDM prodottoModel = new ProdottoModelDM();

    // Costruttore della servlet
    public ConfermaOrdine() {
        super();
    }

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // Verifica se il parametro "confermaOrdine" è presente nella richiesta
        if (request.getParameter("confermaOrdine") != null) {
            // Recupero della sessione corrente, se esiste
        	HttpSession session = request.getSession(false);
            if (session == null) {
                response.sendRedirect(request.getContextPath() + "/user/carrello.jsp");
                return;
            }
            
            // Recupero del carrello dalla sessione
            Carrello carrello = (Carrello) session.getAttribute("carrello");
            if (carrello == null) {
                response.sendRedirect(request.getContextPath() + "/user/carrello.jsp");
                return;
            }

            // Recupero dei prodotti nel carrello
            List<ProdottoBean> prodottiCarrello = carrello.getProdotti();
            
            // Ottenimento della data e ora corrente
            java.util.Date today = new java.util.Date();

            // Recupero dei parametri dalla richiesta
            BigDecimal totaleOrdine = new BigDecimal(request.getParameter("totaleOrdine"));
            int totaleQuantita = Integer.parseInt(request.getParameter("totaleQuantita"));
            String statoOrdine = "In attesa di conferma";

            // Recupero dell'ID utente dalla sessione
            Integer userId = (Integer) session.getAttribute("userId");
            if (userId == null) {
                response.sendRedirect(request.getContextPath() + "/both/login-form-filter.jsp");
                return;
            }

            // Creazione di un nuovo OrdineBean e impostazione dei suoi attributi
            OrdineBean ordine = new OrdineBean();
            ordine.setdataOrdine(new Date(today.getTime()));
            ordine.setoraOrdine(new Time(today.getTime()));
            ordine.settotaleOrdine(totaleOrdine);
            ordine.setquantità(totaleQuantita);
            ordine.setstatoOrdine(statoOrdine);
            ordine.setUserId(userId);


            try {
                // Salva l'ordine nel database
                ordineModel.doSave(ordine);

                // Recupera l'ID dell'ultimo ordine inserito
                int ordineId = ordineModel.getLastOrderId();

                // Salva i dettagli dei prodotti dell'ordine
                for (ProdottoBean prodotto : prodottiCarrello) {
                    ComprendeBean comprende = new ComprendeBean();
                    comprende.setidOrdine(ordineId);
                    comprende.setidProdotto(prodotto.getidProdotto());
                    comprende.setquantità(prodotto.getquantitaScelta());
                    comprende.setprezzo(prodotto.getprezzoUnitario());
                    comprende.setIva(new BigDecimal("22.00"));

                    comprendeModel.doSave(comprende);
                    prodottoModel.aggiornaQuantitaDisponibile(prodotto.getidProdotto(), prodotto.getquantitaScelta());
                }

                // Aggiorna la lista degli ordini nella sessione
                Collection<OrdineBean> ordini = ordineModel.getOrdiniByUserId(userId);
                session.setAttribute("ordini", ordini);
                
                // Svuota il carrello dopo la conferma dell'ordine
                carrello.svuotacarrello();
                
                // Aggiorna il numero di prodotti nel carrello nella sessione
                session.setAttribute("numeroProdottiCarrello", carrello.getNumeroProdotti());
                
                // Reindirizza alla pagina di visualizzazione dell'ordine
                response.sendRedirect(request.getContextPath() + "/OrdineControl?action=view");
            } catch (SQLException e) {
                e.printStackTrace();
                //LOGGER.severe("Si è verificato un'eccezione SQL: " + e.getMessage());
                //response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
            }
        }
    }
}
