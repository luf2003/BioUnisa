package it.unisa.control;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import it.unisa.model.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.List;

public class FatturaControl extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Modelli per gestire le operazioni sui dati degli ordini, prodotti e fatture
    static OrdineModel ordineModel = new OrdineModelDM();
    static ComprendeModel comprendeModel = new ComprendeModelDM();
    static ProdottoModel prodottoModel = new ProdottoModelDM();
    static FatturaModel fatturaModel = new FatturaModelDM();

    // Costruttore della servlet
    public FatturaControl() {
        super();
    }

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Recupera l'ID dell'ordine dalla richiesta
        int idOrdine = Integer.parseInt(request.getParameter("idOrdine"));
        
        try {
            // Recupera l'ordine dal database
            OrdineBean ordine = ordineModel.doRetrieveByKey(idOrdine);
            // Recupera i dettagli dell'ordine dal database
            List<ComprendeBean> dettagliOrdine = (List<ComprendeBean>) comprendeModel.doRetrieveByOrdine(idOrdine);
            
            // Per ogni dettaglio dell'ordine, recupera il prodotto corrispondente e lo associa al dettaglio
            for (ComprendeBean dettaglio : dettagliOrdine) {
                ProdottoBean prodotto = prodottoModel.doRetrieveByKey(dettaglio.getidProdotto());
                dettaglio.setProdotto(prodotto);
            }
            
            // Recupera la fattura dal database
            FatturaBean fattura = fatturaModel.doRetrieveByOrder(idOrdine);
            
            // Imposta il tipo di contenuto della risposta come PDF
            response.setContentType("application/pdf");
            // Imposta l'intestazione della risposta per il download del file PDF
            response.setHeader("Content-Disposition", "attachment; filename=fattura.pdf");
            
            // Ottiene l'output stream per scrivere il PDF
            OutputStream out = response.getOutputStream();
            Document document = new Document();
            PdfWriter.getInstance(document, out);
            
            // Apre il documento per la scrittura
            document.open();
            
            // Impostazioni dei font
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, BaseColor.BLACK);
            Font subTitleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16, BaseColor.BLACK);
            Font tableHeaderFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.WHITE);
            Font tableBodyFont = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);
            
            // Titolo del documento
            Paragraph title = new Paragraph("Fattura", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            
            document.add(new Paragraph(" "));
            
            // Dettagli della fattura
            document.add(new Paragraph("ID Fattura: " + fattura.getidFattura(), tableBodyFont));
            document.add(new Paragraph("Data Fattura: " + fattura.getdataFattura(), tableBodyFont));
            document.add(new Paragraph("Importo: " + fattura.getimporto(), tableBodyFont));
            document.add(new Paragraph(" "));
            
            // Dettagli dell'ordine
            document.add(new Paragraph("Dettagli Ordine", subTitleFont));
            document.add(new Paragraph("ID Ordine: " + ordine.getidOrdine(), tableBodyFont));
            document.add(new Paragraph("Data: " + ordine.getdataOrdine(), tableBodyFont));
            document.add(new Paragraph("Totale: " + ordine.gettotaleOrdine(), tableBodyFont));
            document.add(new Paragraph(" "));
            
            // Tabella dei prodotti
            document.add(new Paragraph("Prodotti:", subTitleFont));
            PdfPTable table = new PdfPTable(5); // 5 colonne
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);
            table.setSpacingAfter(10f);
            
            // Imposta le larghezze delle colonne
            float[] columnWidths = {2f, 5f, 2f, 2f, 2f};
            table.setWidths(columnWidths);
            
            // Intestazioni della tabella
            PdfPCell cell = new PdfPCell(new Phrase("Nome", tableHeaderFont));
            cell.setBackgroundColor(BaseColor.GRAY);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
            
            cell = new PdfPCell(new Phrase("Descrizione", tableHeaderFont));
            cell.setBackgroundColor(BaseColor.GRAY);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
            
            cell = new PdfPCell(new Phrase("Prezzo", tableHeaderFont));
            cell.setBackgroundColor(BaseColor.GRAY);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
            
            cell = new PdfPCell(new Phrase("Quantit�", tableHeaderFont));
            cell.setBackgroundColor(BaseColor.GRAY);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
            
            cell = new PdfPCell(new Phrase("IVA", tableHeaderFont));
            cell.setBackgroundColor(BaseColor.GRAY);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
            
            // Corpo della tabella
            for (ComprendeBean dettaglio : dettagliOrdine) {
                ProdottoBean prodotto = dettaglio.getProdotto();
                
                cell = new PdfPCell(new Phrase(prodotto.getnome(), tableBodyFont));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cell);
                
                // Elabora la descrizione con i tag HTML
                String descrizione = prodotto.getdescrizione().replaceAll("<br>", "\n").replaceAll("<b>", "").replaceAll("</b>", "");
                cell = new PdfPCell(new Phrase(descrizione, tableBodyFont));
                cell.setHorizontalAlignment(Element.ALIGN_LEFT);
                table.addCell(cell);
                
                cell = new PdfPCell(new Phrase(String.valueOf(dettaglio.getprezzo()), tableBodyFont));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cell);
                
                cell = new PdfPCell(new Phrase(String.valueOf(dettaglio.getquantit�()), tableBodyFont));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cell);
                
                cell = new PdfPCell(new Phrase("22%", tableBodyFont));
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cell);
            }
            
            // Aggiunge la tabella al documento
            document.add(table);
            
            // Chiude il documento e l'output stream
            document.close();
            out.close();
        } catch (SQLException | DocumentException e) {
            // Gestione delle eccezioni SQL e DocumentException
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
        }
    }
}
