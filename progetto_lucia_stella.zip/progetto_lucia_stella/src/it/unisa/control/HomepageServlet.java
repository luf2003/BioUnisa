package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModel;
import it.unisa.model.ProdottoModelDM;

/**
 * Servlet implementation class HomepageServlet
 */
@WebServlet("/home")
public class HomepageServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    // il ProdottoModelDM usa il DataSource 
    static boolean isDataSource = true;
    
    // Istanza del modello ProdottoModel per gestire le operazioni sui dati dei prodotti
    static ProdottoModel Model = new ProdottoModelDM();
    
    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera la collezione di prodotti dal modello e la imposta come attributo della richiesta
        try {
            Collection<ProdottoBean> prodotti = Model.doRetrieveAll("");
            HttpSession session = request.getSession();
            session.setAttribute("prodotti", prodotti);
            
            // Inoltra alla pagina both/Home.jsp
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/both/Home.jsp");
            dispatcher.forward(request, response);
        
        } catch (SQLException e) {
            // Gestione delle eccezioni SQL
            System.out.println("Errore:" + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
        }
    }
    
    // Metodo doPost per gestire le richieste POST (inviare informazioni) delega la gestione al metodo doGet
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
