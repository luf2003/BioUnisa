package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Collection;
import it.unisa.model.UtenteBean;
import it.unisa.model.UtenteModelDM;
import it.unisa.model.OrdineBean;
import it.unisa.model.OrdineModelDM;
import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModelDM;

@WebServlet("/loginServlet")
public class Login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Modelli per gestire le operazioni sui dati degli utenti, ordini e prodotti
    private UtenteModelDM utenteModel = new UtenteModelDM();
    private OrdineModelDM ordineModel = new OrdineModelDM(); // per gestire gli ordini
    private ProdottoModelDM prodottoModel = new ProdottoModelDM(); // per gestire i prodotti

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera l'azione richiesta
    	String action = request.getParameter("action");
        // Se l'azione è "register", inoltra alla servlet di registrazione
    	if ("register".equals(action)) {
            request.getRequestDispatcher("/Registrazione").forward(request, response);
        } else {
            // Altrimenti, tenta di effettuare il login dell'utente
        	loginUser(request, response);
        }
    }

    // Metodo per gestire il login dell'utente
    private void loginUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera le credenziali dalla richiesta
    	String email = request.getParameter("username");
        String password = request.getParameter("password");
        try {
            // Verifica se l'utente esiste
            UtenteBean user = utenteModel.doRetrieveByEmail(email);
            if (user == null) {
                // Utente non registrato
                HttpSession session = request.getSession();
                session.setAttribute("nonRegistrato", true);
                request.getRequestDispatcher("/both/registrazione.jsp").forward(request, response);
                return;
            }
            
            // Verifica se la password è corretta
            user = utenteModel.doRetrieveByEmailAndPassword(email, password);
            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("utente", user);  // Memorizza l'oggetto UtenteBean nella sessione
                session.setAttribute("username", user.getusername());
                session.setAttribute("nomeUtente", user.getnome()); // Memorizza il nome dell'utente nella sessione
                session.setAttribute("userId", user.getidUtente());
                session.setAttribute("stato", user.getstato()); // Memorizza lo stato nella sessione

                // Recupera gli ordini dell'utente e li memorizza nella sessione
                Collection<OrdineBean> ordini;
                if ("Amministratore".equalsIgnoreCase(user.getstato())) {  // Usa equalsIgnoreCase per gestire il caso sensibile
                    // Se l'utente è amministratore, recupera tutti gli ordini
                	ordini = ordineModel.getAllOrdini();
                } else {
                    // Altrimenti, recupera solo gli ordini dell'utente
                	ordini = ordineModel.getOrdiniByUserId(user.getidUtente());
                }
                session.setAttribute("ordini", ordini);

                // Recupera i prodotti e li memorizza nella sessione
                Collection<ProdottoBean> prodotti = prodottoModel.doRetrieveAll("");
                session.setAttribute("prodotti", prodotti);

                // Reindirizza alla homepage
                response.sendRedirect(request.getContextPath() + "/both/Home.jsp");
            } else {
                // Password errata
                request.setAttribute("errorMessage", "Password errata. Riprova.");
                request.getRequestDispatcher("/login-form-filter.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            // Gestione delle eccezioni SQL
            request.setAttribute("errorMessage", "Errore interno del server. Riprova più tardi.");
            request.getRequestDispatcher("/login-form-filter.jsp").forward(request, response);
        }
    }

    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Reindirizza alla pagina di registrazione
    	response.sendRedirect(request.getContextPath() + "/registrazione.jsp");
    }
}
