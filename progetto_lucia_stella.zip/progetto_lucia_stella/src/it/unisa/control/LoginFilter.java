package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import it.unisa.model.CheckUserAdminPassword;
import it.unisa.model.UtenteBean;
import it.unisa.model.UtenteModelDM;
import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModel;
import it.unisa.model.ProdottoModelDM;

@WebServlet("/loginFilterServlet")
public class LoginFilter extends HttpServlet {

    // ProdottoModelDM usa il DriverManager
    static boolean isDataSource = true;
    static ProdottoModel Model = new ProdottoModelDM();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            if (CheckUserAdminPassword.checkAdminLogin(email, password)) {
                // Se l'utente � un amministratore autenticato
                invalidateSession(request);
                request.getSession().setAttribute("adminFilterRoles", Boolean.TRUE);
                response.sendRedirect(request.getContextPath() + "/baseFilter.jsp");
            } else {
                UtenteBean utente = CheckUserAdminPassword.checkUserLogin(email, password);
                if (utente != null) {
                    // Se l'utente � un utente registrato autenticato
                    invalidateSession(request); // Invalida la sessione precedente
                    HttpSession session = request.getSession();
                    String nomeUtente = utente.getnome();
                    session.setAttribute("username", nomeUtente); // Imposta l'attributo "username" nella nuova sessione
                    session.setAttribute("userId", utente.getidUtente()); // Imposta l'attributo "userId" nella nuova sessione
                    request.removeAttribute("registrazioneError"); // Rimuovi eventuali attributi non necessari dalla richiesta
                    // Reindirizza alla home page o a qualsiasi altra pagina appropriata
                    try {
                        // Recupera i prodotti
                        Collection<ProdottoBean> prodotti = Model.doRetrieveAll("");
                        session.setAttribute("prodotti", prodotti);

                        // Inoltra la richiesta alla pagina Home.jsp
                        RequestDispatcher dispatcher = request.getRequestDispatcher("/Home.jsp");
                        dispatcher.forward(request, response);
                    } catch (SQLException e) {
                        System.out.println("Error:" + e.getMessage());
                        response.sendRedirect("Errore.jsp");
                    }
                } else {
                    // Se l'utente non � registrato
                    request.setAttribute("nonRegistrato", true); // Imposta l'attributo per indicare che l'utente non � registrato
                    invalidateSession(request); // Invalida la sessione
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/registrazione.jsp");
                    dispatcher.forward(request, response); // Inoltra la richiesta alla pagina di registrazione
                }
            }
        } catch (Exception e) {
            // Se si verifica un errore durante il processo di autenticazione, l'utente rimane sulla pagina di login e visualizza un messaggio di errore
            invalidateSession(request);
            response.sendRedirect(request.getContextPath() + "/login-form-filter.jsp?error=true");
        }
    }

    private void invalidateSession(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
    }

    private String getUserRole(String username) {
        // Simulazione di accesso al database per ottenere il ruolo dell'utente
        // Implementa questa funzione per ottenere il ruolo dell'utente dal database
        // In questo esempio, restituiamo lo stato dell'utente dal database
        return getUserState(username);
    }

    private String getUserState(String username) {
        // Simulazione di accesso al database per ottenere lo stato dell'utente
        // Implementa questa funzione per ottenere lo stato dell'utente dal database
        // In questo esempio, ritorniamo lo stato dell'utente dal database
        return "Registrato";
    }
}
