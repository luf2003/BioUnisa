package it.unisa.control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Logout extends HttpServlet {
    
	// Metodo doGet per gestire le richieste GET (recuperare informazioni)
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Rimuove l'attributo "adminFilterRoles" dalla sessione
		request.getSession().removeAttribute("adminFilterRoles");
        // Invalida la sessione corrente
		request.getSession().invalidate();
        // Reindirizza l'utente alla pagina di login
		String redirectedPage = request.getContextPath() + "/both/login-form-filter.jsp";
        response.sendRedirect(redirectedPage);
    }

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Delegazione della gestione della richiesta al metodo doGet
    	doGet(request, response);
    }
}
