package it.unisa.control;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Collection;
import java.sql.Time;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.unisa.model.ComprendeBean;
import it.unisa.model.ComprendeModel;
import it.unisa.model.ComprendeModelDM;
import it.unisa.model.OrdineBean;
import it.unisa.model.OrdineModel;
import it.unisa.model.OrdineModelDM;
import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModel;
import it.unisa.model.ProdottoModelDM;

@WebServlet("/OrdineControl")
public class OrdineControl extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Istanza dei modelli per gestire le operazioni sui dati di ordini, comprende e prodotti
    static OrdineModel ordineModel = new OrdineModelDM();
    static ComprendeModel comprendeModel = new ComprendeModelDM();
    static ProdottoModel prodottoModel = new ProdottoModelDM();

    // Costruttore della servlet
    public OrdineControl() {
        super();
    }
    
    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Recupera l'azione richiesta
        String action = request.getParameter("action");
        
        
        if (action != null) {
            // Gestione della visualizzazione degli ordini
        	if (action.equals("view")) {
                String ordinamento = request.getParameter("ordinamento");
                
                try {
                    // Recupera tutti gli ordini dal modello e imposta come attributo della richiesta
                    request.setAttribute("ordini", ordineModel.doRetrieveAll(ordinamento));
                } catch (SQLException e) {
                    // Gestione delle eccezioni SQL
                	e.printStackTrace();
                    request.setAttribute("errorMessage", "Errore durante il recupero degli ordini.");
                    getServletContext().getRequestDispatcher("/errore/Errore500.jsp").forward(request, response);
                }

                // Inoltra alla pagina both/OrdineView.jsp
                RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/both/OrdineView.jsp");
                dispatcher.forward(request, response);
                // Gestione della visualizzazione dei dettagli dell'ordine
        		} else if (action.equals("details")) {
                int idOrdine = Integer.parseInt(request.getParameter("idOrdine"));
                try {
                    // Recupera l'ordine e i dettagli dell'ordine dal modello
                    OrdineBean ordine = ordineModel.doRetrieveByKey(idOrdine);
                    Collection<ComprendeBean> dettagliOrdine = comprendeModel.doRetrieveByOrdine(idOrdine);
                    
                    // Per ogni dettaglio dell'ordine, recupera il prodotto corrispondente e lo associa al dettaglio
                    for (ComprendeBean dettaglio : dettagliOrdine) {
                        ProdottoBean prodotto = prodottoModel.doRetrieveByKey(dettaglio.getidProdotto());
                        dettaglio.setProdotto(prodotto);
                    }
                    
                    // Imposta l'ordine e i dettagli dell'ordine come attributi della richiesta
                    request.setAttribute("ordine", ordine);
                    request.setAttribute("dettagliOrdine", dettagliOrdine);
                    // Inoltra alla pagina both/dettagliOrdine.jsp
                    RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/both/dettagliOrdine.jsp");
                    dispatcher.forward(request, response);
                } catch (SQLException e) {
                    // Gestione delle eccezioni SQL
                	e.printStackTrace();
                    getServletContext().getRequestDispatcher("/errore/Errore500.jsp").forward(request, response);
                }
            }
        }
    }

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recupera i parametri dalla richiesta
    	Date dataOrdine = new Date(System.currentTimeMillis());
        Time oraOrdine = new Time(System.currentTimeMillis());
        BigDecimal totaleOrdine = new BigDecimal(request.getParameter("totaleOrdine"));
        int quantità = Integer.parseInt(request.getParameter("quantità"));
        String statoOrdine = "In attesa di conferma";

        // Recupera l'ID utente dalla sessione
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            // Se l'ID utente non è presente nella sessione, reindirizza alla pagina di login
            response.sendRedirect("login-form-filter.jsp");
            return;
        }

        // Crea un nuovo OrdineBean e imposta i suoi attributi
        OrdineBean ordine = new OrdineBean();
        ordine.setdataOrdine(dataOrdine);
        ordine.setoraOrdine(oraOrdine);
        ordine.settotaleOrdine(totaleOrdine);
        ordine.setquantità(quantità);
        ordine.setstatoOrdine(statoOrdine);
        ordine.setUserId(userId);

        try {
            // Salva l'ordine nel database
            ordineModel.doSave(ordine);
            // Reindirizza alla visualizzazione degli ordini
            response.sendRedirect(request.getContextPath() + "/OrdineControl?action=view");
        } catch (SQLException e) {
            // Gestione delle eccezioni SQL
            e.printStackTrace();
            request.setAttribute("errorMessage", "Errore durante il salvataggio dell'ordine.");
            getServletContext().getRequestDispatcher("/errore/Errore500.jsp").forward(request, response);
        }
    }
}