package it.unisa.control;

import it.unisa.model.PreferitiBean;
import it.unisa.model.PreferitiModelDM;
import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModelDM;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/PreferitiControl")
public class PreferitiControl extends HttpServlet {
    private static final long serialVersionUID = 1L;
    // Istanza del modello PreferitiModel e ProdottoModel per gestire le operazioni sui dati dei preferiti e dei prodotti
    private PreferitiModelDM preferitiModel = new PreferitiModelDM();
    private ProdottoModelDM prodottoModel = new ProdottoModelDM();
    
    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recupera la sessione corrente, se esiste
    	HttpSession session = request.getSession(false); 
        if (session == null) {
            // Reindirizza alla pagina di login se la sessione � null
        	response.sendRedirect(request.getContextPath() + "/both/login-form-filter.jsp");  
            return;
        }

        // Recupera l'ID utente dalla sessione
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) { 
            // Reindirizza alla pagina di login se l'ID utente � null
        	response.sendRedirect(request.getContextPath() + "/both/login-form-filter.jsp"); 
            return;
        }

        // Recupera l'ID del prodotto e l'azione dalla richiesta
        String productIdStr = request.getParameter("productId");
        String action = request.getParameter("action");

        if (productIdStr == null || productIdStr.isEmpty()) {
            // Reindirizza alla pagina di errore se l'ID del prodotto non � fornito
        	response.sendRedirect(request.getContextPath() + "/errore/Errore404.jsp");  
            return;
        }

        int productId = Integer.parseInt(productIdStr);

        try {
            if ("remove".equals(action)) {
                // Rimuove il prodotto dai preferiti dell'utente
                preferitiModel.rimuoviDaPreferiti(userId, productId);
            } else {
                // Aggiunge il prodotto ai preferiti dell'utente
                PreferitiBean preferito = new PreferitiBean();
                preferito.setidUtente(userId);
                preferito.setidProdotto(productId);
                preferitiModel.doSave(preferito);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Reindirizza alla pagina di errore in caso di fallimento nel salvataggio/rimozione
            //System.err.println("Error while saving/removing favorite: " + e.getMessage());
            //response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");  
            //return;
        }

        // Reindirizza alla pagina di controllo dei preferiti
        response.sendRedirect(request.getContextPath() + "/PreferitiControl");
    }
    
    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recupera la sessione corrente, se esiste
    	HttpSession session = request.getSession(false);  // false significa che non crea una nuova sessione se non esiste
        if (session == null) {
            // Reindirizza alla pagina di login se la sessione � null
            response.sendRedirect(request.getContextPath() + "/both/login-form-filter.jsp");  
            return;
        }

        // Recupera l'ID utente dalla sessione
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            // Reindirizza alla pagina di login se l'ID utente � null
        	response.sendRedirect(request.getContextPath() + "/both/login-form-filter.jsp");  
            return;
        }

        try {
            // Recupera gli ID dei prodotti preferiti dell'utente
            List<Integer> favoriteProductIds = preferitiModel.getFavoriteProductIds(userId);
            // Recupera i dettagli dei prodotti preferiti
            List<ProdottoBean> favoriteProducts = prodottoModel.getProductsByIds(favoriteProductIds);
            // Imposta i prodotti preferiti come attributo della richiesta
            request.setAttribute("favoriteProducts", favoriteProducts);
        } catch (Exception e) {
            // Reindirizza alla pagina di errore in caso di fallimento nel recupero
            //response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp"); 
            return;
        }

        // Inoltra alla pagina JSP dei preferiti
        request.getRequestDispatcher("/user/preferiti.jsp").forward(request, response);
    }
}