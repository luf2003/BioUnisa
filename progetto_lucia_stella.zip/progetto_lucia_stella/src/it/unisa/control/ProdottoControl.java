package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModel;
import it.unisa.model.ProdottoModelDM;
import it.unisa.model.Carrello;

@WebServlet("/prodotto")
public class ProdottoControl extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Flag per indicare che usa il DataSource
    static boolean isDataSource = true;
    // Istanza del modello ProdottoModel
    static ProdottoModel Model = new ProdottoModelDM();

    // Costruttore della servlet
    public ProdottoControl() {
        super();
    }

    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Recupera il carrello dalla sessione, se non esiste ne crea uno nuovo
        Carrello carrello = (Carrello) request.getSession().getAttribute("carrello");
        if (carrello == null) {
            carrello = new Carrello();
            request.getSession().setAttribute("carrello", carrello);
        }

        // Recupera l'azione richiesta
        String azione = request.getParameter("azione");

        try {
            if (azione != null) {
                if (azione.equalsIgnoreCase("addC")) {
                    // Aggiunge un prodotto al carrello
                    int id = Integer.parseInt(request.getParameter("id"));
                    int quantita = Integer.parseInt(request.getParameter("quantita"));
                    carrello.addProdotto(Model.doRetrieveByKey(id), quantita);
                } else if (azione.equalsIgnoreCase("deleteC")) {
                    // Rimuove un prodotto dal carrello
                    int id = Integer.parseInt(request.getParameter("id"));
                    carrello.deleteProdotto(Model.doRetrieveByKey(id));
                    request.setAttribute("prodottiCarrello", carrello.getProdotti());
                } else if (azione.equalsIgnoreCase("leggi")) {
                    // Legge i dettagli di un prodotto
                    int id = Integer.parseInt(request.getParameter("id"));
                    ProdottoBean prodotto = Model.doRetrieveByKey(id);
                    if (prodotto != null) {
                        request.setAttribute("prodotto", prodotto);
                        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/both/dettaglioprodotto.jsp");
                        dispatcher.forward(request, response);
                        return;
                    }
                } else if (azione.equalsIgnoreCase("inserisci")) {
                    // Inserisce un nuovo prodotto
                    String nome = request.getParameter("nome");
                    String descrizione = request.getParameter("descrizione");
                    String categoria = request.getParameter("categoria");
                    String formato = request.getParameter("formato");
                    double prezzoUnitario = Double.parseDouble(request.getParameter("prezzoUnitario"));
                    int quantitaDisponibile = Integer.parseInt(request.getParameter("quantitaDisponibile"));

                    ProdottoBean bean = new ProdottoBean();
                    bean.setnome(nome);
                    bean.setdescrizione(descrizione);
                    bean.setcategoria(categoria);
                    bean.setformato(formato);
                    bean.setprezzoUnitario(prezzoUnitario);
                    bean.setquantitaDisponibile(quantitaDisponibile);
                    Model.doSave(bean);
                } else if (azione.equalsIgnoreCase("menu")) {
                    // Mostra il menu dei prodotti
                    Collection<ProdottoBean> prodotti = Model.doRetrieveAll(null);
                    request.setAttribute("prodotti", prodotti);
                    RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/both/Menu.jsp");
                    dispatcher.forward(request, response);
                    return;
                }
            }

            // Recupera tutti i prodotti dal modello e li imposta come attributo della richiesta
            Collection<ProdottoBean> prodotti = Model.doRetrieveAll(null);
            request.setAttribute("prodotti", prodotti);
            request.getSession().setAttribute("carrello", carrello);
            request.setAttribute("carrello", carrello);
        } catch (SQLException e) {
            // Gestione delle eccezioni SQL
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
            return;
        }

        // Inoltra alla pagina both/ProductView.jsp
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/both/ProductView.jsp");
        dispatcher.forward(request, response);
    }

    // Metodo doPost per gestire le richieste POST, delega la gestione al metodo doGet
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
