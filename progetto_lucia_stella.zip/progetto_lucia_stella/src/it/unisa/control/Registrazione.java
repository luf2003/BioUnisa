package it.unisa.control;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.google.gson.JsonObject;
import it.unisa.model.UtenteBean;
import it.unisa.model.UtenteModel;
import it.unisa.model.UtenteModelDM;

@WebServlet("/Registrazione")
public class Registrazione extends HttpServlet {
    private static final long serialVersionUID = 1L;
    // Istanza del modello UtenteModel per gestire le operazioni sui dati degli utenti
    private UtenteModel utenteModel = new UtenteModelDM();

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera l'azione richiesta
        String action = request.getParameter("action");

        // Se l'azione � "checkEmail", verifica se l'email � gi� registrata
        if ("checkEmail".equals(action)) {
            checkEmail(request, response);
        } else {
            // Altrimenti, registra un nuovo utente
            registerUser(request, response);
        }
    }

    // Metodo per verificare se l'email � gi� registrata
    private void checkEmail(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Recupera l'email dalla richiesta
    	String email = request.getParameter("email");
        JsonObject jsonResponse = new JsonObject();

        try {
            // Verifica se l'email esiste gi� nel database
            if (utenteModel.doRetrieveByEmail(email) != null) {
                jsonResponse.addProperty("exists", true);
            } else {
                jsonResponse.addProperty("exists", false);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            jsonResponse.addProperty("exists", false);
        }

        // Imposta il tipo di contenuto della risposta come JSON e scrive la risposta
        response.setContentType("application/json");
        response.getWriter().write(jsonResponse.toString());
    }

    // Metodo per registrare un nuovo utente
    private void registerUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera i parametri dalla richiesta
        String email = request.getParameter("email");
        String nome = request.getParameter("nome");
        String cognome = request.getParameter("cognome");
        String indirizzo = request.getParameter("indirizzo");
        String citta = request.getParameter("citta");
        String provincia = request.getParameter("provincia");
        String cap = request.getParameter("cap");
        String password = request.getParameter("password");

        try {
            // Verifica se l'email � gi� registrata
            if (utenteModel.doRetrieveByEmail(email) != null) {
                request.setAttribute("registrazioneError", true);
                request.getRequestDispatcher("/both/login-form-filter.jsp").forward(request, response);
                return;
            }

            // Crea un hash della password
            String hashedPassword = toHash(password);
            // Crea un nuovo oggetto UtenteBean e imposta i suoi attributi
            UtenteBean utente = new UtenteBean();
            utente.setusername(email);
            utente.setpassword(hashedPassword);
            utente.setnome(nome);
            utente.setcognome(cognome);
            utente.setemail(email);
            utente.setindirizzo(indirizzo);
            utente.setcitta(citta);
            utente.setprovincia(provincia);
            utente.setcap(cap);
            utente.setstato("Registrato");

            // Salva il nuovo utente nel database
            utenteModel.doSave(utente);

            // Imposta gli attributi di sessione per il nuovo utente
            HttpSession session = request.getSession();
            session.setAttribute("username", email);
            session.setAttribute("nomeUtente", nome);
            session.setAttribute("userId", utente.getidUtente());
            session.setAttribute("stato", "Registrato");
            session.setAttribute("isRegistrato", true);
            session.setAttribute("registrazioneSuccesso", true);

            // Reindirizza alla pagina di login
            response.sendRedirect(request.getContextPath() + "/both/login-form-filter.jsp");
        } catch (SQLException e) {
            // Gestione delle eccezioni SQL
            log("Errore SQL durante l'inserimento dell'utente: " + e.getMessage(), e);
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
        }
    }

    // Metodo per creare un hash della password utilizzando SHA-512
    private String toHash(String password) {
        String hashString = null;
        try {
            // Crea un'istanza di MessageDigest per SHA-512
            MessageDigest digest = MessageDigest.getInstance("SHA-512");
            // Calcola l'hash della password
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            // Converte l'hash in una stringa esadecimale
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            hashString = hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.out.println(e);
        }
        return hashString;
    }
}
