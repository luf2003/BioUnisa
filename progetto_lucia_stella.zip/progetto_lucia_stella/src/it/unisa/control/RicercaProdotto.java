package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModel;
import it.unisa.model.ProdottoModelDM;

@WebServlet("/RicercaProdottoServlet")
public class RicercaProdotto extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Indica se ProdottoModelDM usa DataSource
    static boolean isDataSource = true;

    // Istanza del modello ProdottoModel per gestire le operazioni sui dati dei prodotti
    static ProdottoModel model = new ProdottoModelDM();

    // Costruttore della servlet
    public RicercaProdotto() {
        super();
    }

    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Imposta il tipo di contenuto della risposta come JSON
    	response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Recupera la query di ricerca dalla richiesta
        String query = request.getParameter("query");

        // Lista per memorizzare i risultati della ricerca
        ArrayList<ProdottoBean> risultato = new ArrayList<>();

        try {
            // Recupera tutti i prodotti dal modello
            Collection<ProdottoBean> prodotti = model.doRetrieveAll(null);
            for (ProdottoBean p : prodotti) {
                // Aggiunge il prodotto al risultato se il nome contiene la query
                if (p.getnome().toLowerCase().contains(query.toLowerCase()) && !risultato.contains(p)) {
                    risultato.add(p);
                }
            }
        } catch (SQLException e) {
            // Gestione delle eccezioni SQL
            e.printStackTrace();
        }

        // Converte l'elenco di prodotti in JSON
        JsonArray jsonArray = new JsonArray();
        for (ProdottoBean p : risultato) {
            JsonObject jsonObj = new JsonObject();
            jsonObj.addProperty("idProdotto", p.getidProdotto());
            jsonObj.addProperty("nome", p.getnome());
            jsonObj.addProperty("immagine", request.getContextPath() + "/" + p.getpercorsoimmagine());
            jsonArray.add(jsonObj);
        }

        // Invia la risposta JSON
        response.getWriter().write(jsonArray.toString());
    }

    // Metodo doPost per gestire le richieste POST, delega la gestione al metodo doGet
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
