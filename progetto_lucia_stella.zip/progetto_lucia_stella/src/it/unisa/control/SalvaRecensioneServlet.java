package it.unisa.control;

import it.unisa.model.RecensisceBean;
import it.unisa.model.RecensisceModelDM;
import it.unisa.model.UtenteModelDM;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SalvaRecensioneServlet")
public class SalvaRecensioneServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    // Istanza dei modelli per gestire le recensioni e gli utenti
    private RecensisceModelDM model;
    private UtenteModelDM utenteModel;

    // Costruttore della servlet
    public SalvaRecensioneServlet() {
        super();
        // Inizializza i modelli
        model = new RecensisceModelDM();
        utenteModel = new UtenteModelDM();
    }

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recupera i parametri dalla richiesta
        String productId = request.getParameter("productId");
        String rating = request.getParameter("rating");
        String reviewText = request.getParameter("reviewText");
        Integer userIdInt = (Integer) request.getSession().getAttribute("userId");

        // Verifica se l'utente � autenticato (userId presente nella sessione)
        if (userIdInt != null) {
            String userId = userIdInt.toString();

            // Crea un oggetto RecensisceBean e imposta i suoi attributi
            RecensisceBean recensione = new RecensisceBean();
            recensione.setIdProdotto(Integer.parseInt(productId));
            recensione.setValutazione(Integer.parseInt(rating));
            recensione.setTestoRecensione(reviewText);
            recensione.setIdUtente(Integer.parseInt(userId));

            try {
                // Tenta di salvare la recensione nel database
                boolean isSaved = model.saveRecensione(recensione);
                if (isSaved) {
                    // Recensione salvata con successo, reindirizza alla pagina dell'ordine
                    request.getSession().setAttribute("successMessage", "Recensione inviata con successo.");
                    response.sendRedirect(request.getContextPath() + "/both/OrdineView.jsp");

                } else {
                    // Fallimento nel salvataggio della recensione, reindirizza alla pagina di errore
                    response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
                }
            } catch (SQLException e) {
                // Gestione delle eccezioni SQL
                e.printStackTrace();
                response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
            }
        } else {
            // ID utente non trovato nella sessione, reindirizza alla pagina di login
            response.sendRedirect(request.getContextPath() + "/both/login-form-filter.jsp");
        }
    }
}
