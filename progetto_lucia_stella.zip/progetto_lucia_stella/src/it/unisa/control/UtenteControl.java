package it.unisa.control;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.util.Collection;
import java.util.logging.Logger;
import javax.servlet.annotation.WebServlet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import it.unisa.model.UtenteBean;
import it.unisa.model.UtenteModel;
import it.unisa.model.UtenteModelDM;
import it.unisa.model.Carrello;

@WebServlet("/UtenteControl")
@MultipartConfig
public class UtenteControl extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Istanza del modello UtenteModel per gestire le operazioni sui dati degli utenti
    static UtenteModel Model = new UtenteModelDM();

    // Costruttore della servlet
    public UtenteControl() {
        super();
    }

    // Metodo doGet per gestire le richieste GET (recuperare informazioni)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera i parametri dalla richiesta
        String azione = request.getParameter("azione");
        String search = request.getParameter("search");
        String from = request.getParameter("from");
        String to = request.getParameter("to");
        String criterio = request.getParameter("criterio");
        

        
        try {
            if (azione != null) {
                switch (azione.toLowerCase()) {
                    case "registra":
                        // Gestisce la registrazione di un nuovo utente
                        registraUtente(request, response);
                        break;
                    case "updateprofile":
                        // Gestisce l'aggiornamento del profilo utente
                        updateProfile(request, response);
                        break;
                    case "addcontact":
                        // Gestisce l'aggiunta di un nuovo contatto
                        addContact(request, response);
                        break;
                    case "viewusers":
                        // Gestisce la visualizzazione degli utenti
                        viewUsers(request, response, search, from, to, criterio);
                        break;
                    default:
                        // Reindirizza alla home se l'azione non è riconosciuta
                        forwardToHome(request, response);
                        break;
                }
            } else {
                // Visualizza tutti gli utenti se non viene specificata alcuna azione
                viewUsers(request, response, search, from, to, criterio);
            }
        } catch (SQLException e) {
            // Gestione dell'eccezione SQL
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
        }
    }

    // Metodo doPost per gestire le richieste POST, delega la gestione al metodo doGet
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    // Metodo per registrare un nuovo utente
    private void registraUtente(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String email = request.getParameter("email");
        String nome = request.getParameter("nome");
        String cognome = request.getParameter("cognome");
        String indirizzo = request.getParameter("indirizzo");
        String citta = request.getParameter("citta");
        String provincia = request.getParameter("provincia");
        String cap = request.getParameter("cap");
        String telefono = request.getParameter("telefono");
        String nuovoRecapito = request.getParameter("nuovoRecapito");
        String password = request.getParameter("password");
        String stato = "Registrato"; // stato fisso per la registrazione

        // Crea un nuovo oggetto UtenteBean e imposta i suoi attributi
        UtenteBean bean = new UtenteBean();
        bean.setusername(email);
        bean.setcognome(cognome);
        bean.setemail(email);
        bean.settelefono(telefono);
        bean.setnuovoRecapito(nuovoRecapito);
        bean.setpassword(password);
        bean.setnome(nome);
        bean.setindirizzo(indirizzo);
        bean.setcitta(citta);
        bean.setprovincia(provincia);
        bean.setcap(cap);
        bean.setstato(stato);
        Model.doSave(bean);

        // Aggiunge un carrello vuoto per il nuovo utente
        Carrello carrello = new Carrello();
        request.getSession().setAttribute("carrello", carrello);

        // Reindirizza alla pagina di login con un messaggio di successo
        request.setAttribute("registrazioneSuccesso", true);
        forwardToLogin(request, response);
    }

    // Metodo per aggiornare il profilo utente
    private void updateProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        // Recupera i parametri dalla richiesta
        String email = request.getParameter("email");
        String telefono = request.getParameter("telefono");
        String indirizzo = request.getParameter("indirizzo");
        String nuovoRecapito = request.getParameter("nuovoRecapito");
        String citta = request.getParameter("citta");
        String provincia = request.getParameter("provincia");
        String cap = request.getParameter("cap");
        
        // Recupera l'utente dalla sessione
        UtenteBean utente = (UtenteBean) request.getSession().getAttribute("utente");

        if (utente != null) {
            // Aggiorna i dati dell'utente
            utente.setemail(email);
            utente.settelefono(telefono);
            utente.setindirizzo(indirizzo);
            utente.setnuovoRecapito(nuovoRecapito);
            utente.setcitta(citta);
            utente.setprovincia(provincia);
            utente.setcap(cap);
            
            // Gestione del caricamento dell'immagine del profilo
            Part filePart = request.getPart("profileImage");
            if (filePart != null && filePart.getSize() > 0) {
                String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                String uploadDir = getServletContext().getRealPath("/") + "uploads";
                File uploadDirFile = new File(uploadDir);
                if (!uploadDirFile.exists()) {
                    uploadDirFile.mkdir();
                }
                File file = new File(uploadDir, fileName);
                try (InputStream input = filePart.getInputStream()) {
                    Files.copy(input, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
                }
                utente.setProfileImagePath("uploads/" + fileName);
            }

            // Salva le modifiche nel database
            Model.doUpdate(utente);
            request.getSession().setAttribute("utente", utente);
        }
        // Reindirizza alla pagina del profilo utente
        response.sendRedirect(request.getContextPath() + "/user/profilo.jsp");
    }

    // Metodo per aggiungere un nuovo contatto
    private void addContact(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        // Recupera il nuovo recapito dalla richiesta
    	String nuovoRecapito = request.getParameter("nuovoRecapito");

        // Recupera l'utente dalla sessione
        UtenteBean utente = (UtenteBean) request.getSession().getAttribute("utente");

        if (utente != null && nuovoRecapito != null && !nuovoRecapito.isEmpty()) {
            // Recupera l'utente dal database per evitare di sovrascrivere altri campi
            UtenteBean utenteDb = Model.doRetrieveByKey(utente.getidUtente());

            if (utenteDb != null) {
                // Aggiorna il nuovo recapito e salva le modifiche nel database
                utenteDb.setnuovoRecapito(nuovoRecapito);
                Model.doUpdate(utenteDb);
                request.getSession().setAttribute("utente", utenteDb);
            }
        }
        // Reindirizza alla pagina del profilo utente
        response.sendRedirect(request.getContextPath() + "/user/profilo.jsp");
    }

    // Metodo per visualizzare gli utenti
    private void viewUsers(HttpServletRequest request, HttpServletResponse response, String search, String from, String to, String criterio)
            throws ServletException, IOException, SQLException {

        Collection<UtenteBean> utenti;

        // Filtra gli utenti in base ai parametri di ricerca
        if (search != null && !search.isEmpty()) {
            if ("email".equalsIgnoreCase(criterio)) {
                utenti = Model.cercaUtentiPerEmail(search);
            } else {
                utenti = Model.cercaUtentiPerNome(search);
            }
        } else if (from != null && to != null && !from.isEmpty() && !to.isEmpty()) {
            utenti = Model.filtraUtenti(from.charAt(0), to.charAt(0));
        } else {
            utenti = Model.doRetrieveAll("nome");
        }
        request.setAttribute("utenti", utenti);
        request.getRequestDispatcher("/admin/Utenti.jsp").forward(request, response);
    }

    // Metodo per reindirizzare alla home
    private void forwardToHome(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/index.jsp");
        dispatcher.forward(request, response);
    }

    // Metodo per reindirizzare alla pagina di login
    private void forwardToLogin(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/login-form-filter.jsp");
        dispatcher.forward(request, response);
    }
}
