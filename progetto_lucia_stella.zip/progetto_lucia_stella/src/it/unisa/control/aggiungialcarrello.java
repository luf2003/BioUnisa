package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import it.unisa.model.ProdottoBean;
import it.unisa.model.ProdottoModel;
import it.unisa.model.ProdottoModelDM;
import it.unisa.model.Carrello;

@WebServlet("/aggiungiAlCarrello")
public class aggiungialcarrello extends HttpServlet {

    // Metodo doPost per gestire le richieste POST (inviare informazioni)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Recupero dell'ID del prodotto dalla richiesta
            int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));
            // Recupero della quantit� selezionata dall'utente dalla richiesta
            int nuovaQuantita = Integer.parseInt(request.getParameter("quantita"));

            // Recupero del carrello dalla sessione
            HttpSession session = request.getSession();
            Carrello carrello = (Carrello) session.getAttribute("carrello");
            if (carrello == null) {
                // Se il carrello non esiste, ne crea uno nuovo e lo salva nella sessione
            	carrello = new Carrello();
                session.setAttribute("carrello", carrello);
            } else {
            }

            // Verifica della presenza del prodotto nel carrello
            ProdottoBean prodottoEsistente = carrello.getProdottoById(idProdotto);
            if (prodottoEsistente != null) {
                // Aggiornamento della quantit� del prodotto se gi� presente nel carrello
                carrello.updateQuantitaProdotto(idProdotto, nuovaQuantita);
            } else {
                // Aggiunta del prodotto al carrello se non presente
                // Recupero del prodotto dal database
                ProdottoModel prodottoModel = new ProdottoModelDM();
                ProdottoBean prodotto = prodottoModel.doRetrieveByKey(idProdotto);

                // Aggiunta del prodotto al carrello se trovato nel database
                if (prodotto != null) {
                    carrello.addProdotto(prodotto, nuovaQuantita);
                } else {
                    // Se il prodotto non viene trovato nel database, reindirizza alla pagina di errore 404
                    response.sendRedirect(request.getContextPath() + "/errore/Errore404.jsp");
                    return;
                }
            }

            // Aggiornamento del carrello nella sessione
            session.setAttribute("carrello", carrello);

            // Aggiornamento del numero di prodotti nel carrello nella sessione
            session.setAttribute("numeroProdottiCarrello", carrello.getNumeroProdotti());

            // Impostazione dell'attributo prodottiCarrello nella richiesta
            request.setAttribute("prodottiCarrello", carrello.getProdotti());

            // Reindirizzamento dell'utente alla pagina del carrello
            RequestDispatcher dispatcher = request.getRequestDispatcher("/user/carrello.jsp");
            dispatcher.forward(request, response);

        } catch (NumberFormatException e) {
            // Gestione degli errori di formattazione dei numeri
            response.sendRedirect(request.getContextPath() + "/errore/Errore400.jsp");
        } catch (SQLException e) {
            // Gestione degli errori SQL
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
        } catch (Exception e) {
            // Gestione degli errori generici
            response.sendRedirect(request.getContextPath() + "/errore/Errore500.jsp");
        }
    }
}
