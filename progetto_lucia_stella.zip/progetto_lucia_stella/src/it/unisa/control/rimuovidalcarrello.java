package it.unisa.control;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import it.unisa.model.Carrello;
import it.unisa.model.ProdottoBean;

@WebServlet("/rimuoviDalCarrello")
public class rimuovidalcarrello extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
        // Controlla se l'azione richiesta � quella di svuotare il carrello
        String azione = request.getParameter("azione");
        if (azione != null && azione.equals("svuotaCarrello")) {
            // Ottiene il carrello dalla sessione
            HttpSession session = request.getSession();
            Carrello carrello = (Carrello) session.getAttribute("carrello");

            // Se il carrello non � presente nella sessione, non c'� nulla da svuotare
            if (carrello != null) {
                // Svuota completamente il carrello
                carrello.svuotacarrello();

                // Aggiorna il carrello e il numero di prodotti nella sessione
                session.setAttribute("carrello", carrello);
                session.setAttribute("numeroProdottiCarrello", carrello.getNumeroProdotti());

                // Reindirizza alla pagina del carrello
                response.sendRedirect(request.getContextPath() + "/user/carrello.jsp");
                return;
            }
        }
        
        // Se l'azione richiesta non � quella di svuotare il carrello, gestisci la rimozione di un singolo prodotto
        // Recupera l'id del prodotto da rimuovere dal carrello
        int idProdotto = Integer.parseInt(request.getParameter("idProdotto"));

        // Recupera il carrello dalla sessione
        HttpSession session = request.getSession();
        Carrello carrello = (Carrello) session.getAttribute("carrello");

        // Se il carrello non � presente nella sessione, crea un nuovo carrello
        if (carrello == null) {
            carrello = new Carrello();
            session.setAttribute("carrello", carrello);
        }

        // Rimuove il prodotto dal carrello
        List<ProdottoBean> prodottiCarrello = carrello.getProdotti();
        ProdottoBean prodottoDaRimuovere = null; // Variabile per memorizzare il prodotto da rimuovere
        for (ProdottoBean prodotto : prodottiCarrello) {
            if (prodotto.getidProdotto() == idProdotto) {
                prodottoDaRimuovere = prodotto; // Memorizza il prodotto da rimuovere
                break;
            }
        }
        
        // Rimuovi il prodotto se � stato trovato
        if (prodottoDaRimuovere != null) {
            carrello.deleteProdotto(prodottoDaRimuovere);
        }
        
        // Aggiorna il carrello e il numero di prodotti nella sessione dopo aver apportato modifiche
        session.setAttribute("carrello", carrello);
        session.setAttribute("numeroProdottiCarrello", carrello.getNumeroProdotti());

        // Reindirizza alla pagina del carrello
        response.sendRedirect(request.getContextPath() + "/user/carrello.jsp");
    }
}
