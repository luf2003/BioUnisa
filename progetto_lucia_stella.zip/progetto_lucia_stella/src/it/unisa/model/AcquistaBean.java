package it.unisa.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

public class AcquistaBean implements Serializable {

    private static final long serialVersionUID = 1L;

    Date dataAcquisto;
    Time oraAcquisto;
    int idUtente;
    int idProdotto;

    public AcquistaBean() {
        dataAcquisto = null;
        oraAcquisto = null;
        idUtente = -1;
        idProdotto = -1;
    }

    public Date getdataAcquisto() {
        return dataAcquisto;
    }

    public void setdataAcquisto(Date dataAcquisto) {
        this.dataAcquisto = dataAcquisto;
    }

    public Time getoraAcquisto() {
        return oraAcquisto;
    }

    public void setoraAcquisto(Time oraAcquisto) {
        this.oraAcquisto = oraAcquisto;
    }

    public int getidUtente() {
        return idUtente;
    }

    public void setidUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public int getidProdotto() {
        return idProdotto;
    }

    public void setidProdotto(int idProdotto) {
        this.idProdotto = idProdotto;
    }

    @Override
    public String toString() {
        return "Acquisto [Data: " + dataAcquisto + ", Ora: " + oraAcquisto +
               ", ID Utente: " + idUtente + ", ID Prodotto: " + idProdotto + "]";
    }
}
