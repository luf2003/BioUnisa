package it.unisa.model;

import java.sql.SQLException;
import java.util.Collection;

public interface AcquistaModel {
    public void doSave(AcquistaBean acquisto) throws SQLException;
    public AcquistaBean doRetrieveByKey(int code) throws SQLException;
    public Collection<AcquistaBean> doRetrieveAll(String order) throws SQLException;

}