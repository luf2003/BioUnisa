package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;
import java.util.Collection;
import java.util.LinkedList;

//Implementazione del modello AcquistaModel per gestire le operazioni sui dati degli acquisti
public class AcquistaModelDM implements AcquistaModel {

    // Nome della tabella nel database
    private static final String TABLE_NAME = "acquista";

    // Salva un nuovo acquisto nel database
    @Override
    public synchronized void doSave(AcquistaBean acquisto) throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per inserire un nuovo acquisto
        String insertSQL = "INSERT INTO " + AcquistaModelDM.TABLE_NAME
                + " (dataAcquisto, oraAcquisto, idUtente, idProdotto) VALUES (?, ?, ?, ?)";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(insertSQL);
            // Imposta i parametri della query
            preparedStatement.setDate(1, acquisto.getdataAcquisto());
            preparedStatement.setTime(2, acquisto.getoraAcquisto());
            preparedStatement.setInt(3, acquisto.getidUtente());
            preparedStatement.setInt(4, acquisto.getidProdotto());
            // Esegue l'aggiornamento del database
            preparedStatement.executeUpdate();

            // Conferma la transazione
            connection.commit();
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

    // Recupera un acquisto dal database utilizzando la chiave primaria
    @Override
    public synchronized AcquistaBean doRetrieveByKey(int code) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        AcquistaBean bean = new AcquistaBean();

        // Query SQL per selezionare un acquisto tramite idAcquisto
        String selectSQL = "SELECT * FROM " + AcquistaModelDM.TABLE_NAME + " WHERE idAcquisto = ?";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            // Imposta il parametro della query
            preparedStatement.setInt(1, code);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                bean.setdataAcquisto(rs.getDate("dataAcquisto"));
                bean.setoraAcquisto(rs.getTime("oraAcquisto"));
                bean.setidUtente(rs.getInt("idUtente"));
                bean.setidProdotto(rs.getInt("idProdotto"));
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return bean;
    }

    // Recupera tutti gli acquisti dal database con un possibile ordine
    @Override
    public synchronized Collection<AcquistaBean> doRetrieveAll(String order) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Collezione per memorizzare tutti gli acquisti recuperati
        Collection<AcquistaBean> acquisti = new LinkedList<AcquistaBean>();

        // Query SQL per selezionare tutti gli acquisti
        String selectSQL = "SELECT * FROM " + AcquistaModelDM.TABLE_NAME;

        // Aggiunge la clausola ORDER BY se l'ordine � specificato
        if (order != null && !order.equals("")) {
            selectSQL += " ORDER BY " + order;
        }

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                AcquistaBean bean = new AcquistaBean();
                
                bean.setdataAcquisto(rs.getDate("dataAcquisto"));
                bean.setoraAcquisto(rs.getTime("oraAcquisto"));
                bean.setidUtente(rs.getInt("idUtente"));
                bean.setidProdotto(rs.getInt("idProdotto"));
                acquisti.add(bean);
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return acquisti;
    }
}
