package it.unisa.model;

import java.util.ArrayList;
import java.util.List;


//Classe che rappresenta un carrello 
public class Carrello {

    // Lista di prodotti nel carrello
	private List<ProdottoBean> prodotti;
	
    // Costruttore che inizializza una lista vuota di prodotti
	public Carrello() {
		prodotti = new ArrayList<ProdottoBean>();
	}
	
    // Aggiunge un prodotto al carrello con una determinata quantit�
    public void addProdotto(ProdottoBean prodotto, int quantita) {
        boolean prodottoEsistente = false;
        // Controlla se il prodotto � gi� presente nel carrello
        for (ProdottoBean p : prodotti) {
            if (p.getidProdotto() == prodotto.getidProdotto()) {
                // Se il prodotto � gi� presente, aggiorna la quantit�
            	p.setquantitaScelta(p.getquantitaScelta() + quantita);
                prodottoEsistente = true;
                break;
            }
        }
        // Se il prodotto non � presente, lo aggiunge alla lista
        if (!prodottoEsistente) {
            prodotto.setquantitaScelta(quantita);
            prodotti.add(prodotto);
        }
    }


    // Restituisce il prodotto dal carrello dato il suo ID
    public ProdottoBean getProdottoById(int idProdotto) {
        for (ProdottoBean prodotto : prodotti) {
            if (prodotto.getidProdotto() == idProdotto) {
                return prodotto;
            }
        }
        return null; // Ritorna null se il prodotto non � stato trovato
    }
    

    // Aggiorna la quantit� di un prodotto nel carrello
    public void updateQuantitaProdotto(int idProdotto, int nuovaQuantita) {
        for (ProdottoBean prodotto : prodotti) {
            if (prodotto.getidProdotto() == idProdotto) {
                // Imposta la nuova quantit� specificata
                prodotto.setquantitaScelta(nuovaQuantita);
                return;
            }
        }
    }

    // Rimuove un prodotto dal carrello
	public void deleteProdotto(ProdottoBean product) {
	    for (int i = 0; i < prodotti.size(); i++) {
	        ProdottoBean prod = prodotti.get(i);
	        if (prod.getidProdotto() == product.getidProdotto()) {
                // Rimuove il prodotto dalla lista
	        	prodotti.remove(i);
	            break;
	        }
	    }
 	}

    // Metodo per svuotare completamente il carrello
    public void svuotacarrello() {
        prodotti.clear(); // Rimuove tutti i prodotti dal carrello
    }

    // Restituisce la lista dei prodotti nel carrello
	public List<ProdottoBean> getProdotti() {
		return  prodotti;
	}
	
    // Metodo per ottenere il numero totale di prodotti nel carrello considerando le quantit�
    public int getNumeroProdotti() {
        int numeroProdotti = 0;
        // Somma le quantit� di tutti i prodotti nel carrello
        for (ProdottoBean prodotto : prodotti) {
            numeroProdotti += prodotto.getquantitaScelta();
        }
        return numeroProdotti;
    }
}
