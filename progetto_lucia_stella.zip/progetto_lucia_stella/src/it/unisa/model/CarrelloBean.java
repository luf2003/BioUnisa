package it.unisa.model;

import java.io.Serializable;

public class CarrelloBean implements Serializable {

    private static final long serialVersionUID = 1L;

    int IDCarrello;
    int Quantit�;

    public CarrelloBean() {
    	IDCarrello = -1;
    	Quantit� = 0;
    }

    public int getIDCarrello() {
        return IDCarrello;
    }

    public void setIdCarrello(int IDCarrello) {
        this.IDCarrello = IDCarrello;
    }

    public int getQuantit�() {
        return Quantit�;
    }

    public void setQuantit�(int quantit�) {
        this.Quantit� = quantit�;
    }

    @Override
    public String toString() {
        return "CarrelloBean [IDCarrello=" + IDCarrello + ", Quantit�=" + Quantit� + "]";
    }
}
