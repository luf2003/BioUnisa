package it.unisa.model;

import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import it.unisa.model.DriverManagerConnectionPool;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//Classe per gestire il controllo delle credenziali di accesso degli utenti e degli amministratori
public class CheckUserAdminPassword {

    // Metodo principale per testare l'hashing delle password
    public static void main(String[] args) {
        String password = "passwordDaHashare";
        String hashedPassword = toHash(password);
    }

    // Metodo per hashare una password utilizzando SHA-512
    public static String toHash(String password) {
        String hashString = null;
        try {
            // Utilizza l'algoritmo SHA-512 per hashare la password
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-512");
            byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                // Converte ogni byte in una stringa esadecimale
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            hashString = hexString.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            System.out.println(e);
        }
        return hashString;
    }

    // Metodo per controllare le credenziali di accesso di un utente
    public static UtenteBean checkUserLogin(String username, String password) {
        try (Connection connection = DriverManagerConnectionPool.getConnection()) {
            // Query SQL per selezionare l'utente con il username specificato
        	String query = "SELECT * FROM utente WHERE username = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, username);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        // Recupera la password hashata memorizzata nel database
                    	String storedHashedPassword = resultSet.getString("password");
                        // Hasha la password inserita dall'utente
                    	String hashedPassword = toHash(password);
                        boolean result = hashedPassword.equals(storedHashedPassword);
                        System.out.println("Risultato del controllo delle credenziali: " + result);
                        if (result) {
                            // Se le password corrispondono, crea un oggetto UtenteBean con i dati dell'utente
                        	UtenteBean user = new UtenteBean();
                            user.setidUtente(resultSet.getInt("idUtente"));
                            user.setusername(resultSet.getString("username"));
                            user.setemail(resultSet.getString("email"));
                            user.setnome(resultSet.getString("nome"));
                            user.setcognome(resultSet.getString("cognome"));
                            user.settelefono(resultSet.getString("telefono"));
                            user.setnuovoRecapito(resultSet.getString("nuovoRecapito"));
                            user.setindirizzo(resultSet.getString("indirizzo"));
                            user.setcitta(resultSet.getString("citta"));
                            user.setprovincia(resultSet.getString("provincia"));
                            user.setcap(resultSet.getString("cap"));
                            user.setstato(resultSet.getString("stato"));
                            user.setProfileImagePath(resultSet.getString("profileImagePath")); // Imposta profileImagePath


                            return user;
                        }
                    } else {
                        // Se nessun utente viene trovato con il username specificato
                        System.out.println("Nessun utente trovato con username: " + username);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Metodo per controllare le credenziali di accesso di un amministratore
    public static boolean checkAdminLogin(String username, String password) {
        try (Connection connection = DriverManagerConnectionPool.getConnection()) {
            // Query SQL per selezionare l'amministratore con il username specificato
        	String query = "SELECT * FROM utente WHERE username = ? AND stato = 'Amministratore'";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, username);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        // Recupera la password hashata memorizzata nel database
                    	String storedHashedPassword = resultSet.getString("password");
                        // Hasha la password inserita dall'utente
                    	String hashedPassword = toHash(password);
                        // Verifica se le password corrispondono
                    	return hashedPassword.equals(storedHashedPassword);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
