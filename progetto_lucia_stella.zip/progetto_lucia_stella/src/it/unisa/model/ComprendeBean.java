package it.unisa.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class ComprendeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private int idOrdine;
    private int idProdotto;
    private int quantit�;
    private double prezzo;
    private BigDecimal iva;
    private ProdottoBean prodotto; // Aggiungi questo campo

    public ComprendeBean() {
        this.idOrdine = -1;
        this.idProdotto = -1;
        this.quantit� = 0;
        this.prezzo = 0.0;
        this.iva = BigDecimal.ZERO;
        this.prodotto = null; // Inizializza il prodotto come null
    }

    // Getter e setter per i campi esistenti
    public int getidOrdine() {
        return idOrdine;
    }

    public void setidOrdine(int idOrdine) {
        this.idOrdine = idOrdine;
    }

    public int getidProdotto() {
        return idProdotto;
    }

    public void setidProdotto(int idProdotto) {
        this.idProdotto = idProdotto;
    }

    public int getquantit�() {
        return quantit�;
    }

    public void setquantit�(int quantit�) {
        this.quantit� = quantit�;
    }

    public double getprezzo() {
        return prezzo;
    }

    public void setprezzo(double prezzo) {
        this.prezzo = prezzo;
    }

    public BigDecimal getIva() {
        return iva;
    }

    public void setIva(BigDecimal iva) {
        this.iva = iva;
    }

    // Getter e setter per il campo prodotto
    public ProdottoBean getProdotto() {
        return prodotto;
    }

    public void setProdotto(ProdottoBean prodotto) {
        this.prodotto = prodotto;
    }

    @Override
    public String toString() {
        return "ComprendeBean{" +
                "idOrdine=" + idOrdine +
                ", idProdotto=" + idProdotto +
                ", quantit�=" + quantit� +
                ", prezzo=" + prezzo +
                ", iva=" + iva +
                ", prodotto=" + prodotto +
                '}';
    }
}
