package it.unisa.model;

import java.sql.SQLException;
import java.util.Collection;

public interface ComprendeModel {
    public void doSave(ComprendeBean comprende) throws SQLException;
    public ComprendeBean doRetrieveByKey (int code) throws SQLException;
    public Collection<ComprendeBean> doRetrieveByOrdine(int idOrdine) throws SQLException;
}