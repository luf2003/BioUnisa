package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

//Implementazione del modello ComprendeModel per gestire le operazioni sui dati degli ordini
public class ComprendeModelDM implements ComprendeModel {

    // Nome della tabella nel database
    private static final String TABLE_NAME = "comprende";

    // Salva un nuovo elemento comprende nel database
    @Override
    public synchronized void doSave(ComprendeBean comprende) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per inserire un nuovo elemento comprende
        String insertSQL = "INSERT INTO " + ComprendeModelDM.TABLE_NAME
                + " (idOrdine, idProdotto, quantit�, Prezzo, Iva) VALUES (?, ?, ?, ?, ?)";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            connection.setAutoCommit(false); // Disabilita l'autocommit

            preparedStatement = connection.prepareStatement(insertSQL);
            // Imposta i parametri della query
            preparedStatement.setInt(1, comprende.getidOrdine());
            preparedStatement.setInt(2, comprende.getidProdotto());
            preparedStatement.setInt(3, comprende.getquantit�());
            preparedStatement.setDouble(4, comprende.getprezzo());
            preparedStatement.setBigDecimal(5, comprende.getIva());
            // Esegue l'aggiornamento del database
            preparedStatement.executeUpdate();

            // Conferma la transazione
            connection.commit();
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback(); // Rollback esplicito in caso di errore
            }
            throw new SQLException("Errore durante il salvataggio dell'elemento comprende: " + e.getMessage());
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.setAutoCommit(true); // Ripristina l'autocommit
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

    // Recupera un elemento comprende dal database utilizzando la chiave primaria
    @Override
    public synchronized ComprendeBean doRetrieveByKey (int code) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        ComprendeBean bean = new ComprendeBean();

        // Query SQL per selezionare un elemento comprende tramite idOrdine
        String selectSQL = "SELECT * FROM " + ComprendeModelDM.TABLE_NAME + " WHERE idOrdine = ?";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            // Imposta il parametro della query
            preparedStatement.setInt(1, code);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                bean.setidOrdine(rs.getInt("idOrdine"));
                bean.setidProdotto(rs.getInt("idProdotto"));
                bean.setquantit�(rs.getInt("quantit�"));
                bean.setprezzo(rs.getDouble("Prezzo"));
                bean.setIva(rs.getBigDecimal("Iva"));
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return bean;
    }

    // Recupera tutti gli elementi comprende di un ordine dal database
    public synchronized Collection<ComprendeBean> doRetrieveByOrdine(int idOrdine) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        // Collezione per memorizzare tutti i dettagli dell'ordine
        Collection<ComprendeBean> dettagliOrdine = new LinkedList<>();

        // Query SQL per selezionare tutti gli elementi comprende di un ordine tramite idOrdine
        String selectSQL = "SELECT * FROM " + ComprendeModelDM.TABLE_NAME + " WHERE idOrdine = ?";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            // Imposta il parametro della query
            preparedStatement.setInt(1, idOrdine);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                ComprendeBean bean = new ComprendeBean();
                bean.setidOrdine(rs.getInt("idOrdine"));
                bean.setidProdotto(rs.getInt("idProdotto"));
                bean.setquantit�(rs.getInt("quantit�"));
                bean.setprezzo(rs.getDouble("Prezzo"));
                bean.setIva(rs.getBigDecimal("Iva"));
                dettagliOrdine.add(bean);
            }
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return dettagliOrdine;
    }
}
