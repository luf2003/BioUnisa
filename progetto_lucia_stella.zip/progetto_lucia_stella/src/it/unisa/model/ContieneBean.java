package it.unisa.model;

import java.io.Serializable;

public class ContieneBean implements Serializable {

    private static final long serialVersionUID = 1L;

    int IDCarrello;
    int idProdotto;
    int Quantit�;

    public ContieneBean() {
    	IDCarrello = -1;
        idProdotto = -1;
        Quantit� = 0;
    }

    public int getIDCarrello() {
        return IDCarrello;
    }

    public void setID_Carrello(int IDCarrello) {
        this.IDCarrello = IDCarrello;
    }

    public int getidProdotto() {
        return idProdotto;
    }

    public void setidProdotto(int idProdotto) {
        this.idProdotto = idProdotto;
    }

    public int getQuantit�() {
        return Quantit�;
    }

    public void setQuantit�(int Quantit�) {
        this.Quantit� = Quantit�;
    }

    @Override
    public String toString() {
        return "ContieneBean [IDCarrello=" + IDCarrello + ", idProdotto=" + idProdotto + ", Quantit�=" + Quantit� + "]";
    }
}
