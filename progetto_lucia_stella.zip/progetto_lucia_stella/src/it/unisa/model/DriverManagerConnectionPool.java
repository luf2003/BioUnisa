package it.unisa.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

//La classe utilizza una lista di connessioni libere (freeDbConnections) per gestire il pool e un metodo createDBConnection per creare nuove connessioni. 
//Il metodo getConnection permette di ottenere una connessione dal pool.
public class DriverManagerConnectionPool  {

    // Lista di connessioni libere
	private static List<Connection> freeDbConnections;

    // Blocco statico per inizializzare la lista di connessioni e caricare il driver JDBC
	static {
		freeDbConnections = new LinkedList<Connection>();
		try {
            // Carica il driver JDBC per MySQL
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
            // Se il driver non viene trovato, stampa un messaggio di errore
			System.out.println("DB driver not found:"+ e.getMessage());
		} 
	}
	
    // Metodo privato per creare una nuova connessione al database
	private static synchronized Connection createDBConnection() throws SQLException {
		Connection newConnection = null;
        // Parametri di connessione al database
		String ip = "localhost";
		String port = "3306";
		String db = "progetto_lucia_stella";
		String username = "root";
		String password = "Lucia00";

        // Crea una nuova connessione al database
		newConnection = DriverManager.getConnection("jdbc:mysql://"+ ip+":"+ port+"/"+db+"?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", username, password);

        // Disabilita l'autocommit per la nuova connessione
        newConnection.setAutoCommit(false);
		return newConnection;
	}

    // Metodo per ottenere una connessione dal pool
	public static synchronized Connection getConnection() throws SQLException {
		Connection connection;

        // Se ci sono connessioni libere, ne restituisce una
		if (!freeDbConnections.isEmpty()) {
			connection = (Connection) freeDbConnections.get(0);
			freeDbConnections.remove(0);

			try {
                // Se la connessione � chiusa, ne ottiene una nuova ricorsivamente
				if (connection.isClosed())
					connection = getConnection();
			} catch (SQLException e) {
				connection.close();
				connection = getConnection();
			}
		} else {
            // Se non ci sono connessioni libere, ne crea una nuova
			connection = createDBConnection();		
		}

		return connection;
	}

    // Metodo per rilasciare una connessione e restituirla al pool
	public static synchronized void releaseConnection(Connection connection) throws SQLException {
        // Se la connessione non � null, la aggiunge alla lista delle connessioni libere
		if(connection != null) freeDbConnections.add(connection);
	}
}
