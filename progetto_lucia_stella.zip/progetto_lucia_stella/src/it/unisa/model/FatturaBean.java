package it.unisa.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

public class FatturaBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private int idFattura;
    private Date dataFattura;
    private BigDecimal importo;
    private int idOrdine;

    public FatturaBean() {
        this.idFattura = -1;
        this.dataFattura = null;
        this.importo = BigDecimal.ZERO;
        this.idOrdine = -1;
    }

    public int getidFattura() {
        return idFattura;
    }

    public void setidFattura(int idFattura) {
        this.idFattura = idFattura;
    }

    public Date getdataFattura() {
        return dataFattura;
    }

    public void setdataFattura(Date dataFattura) {
        this.dataFattura = dataFattura;
    }

    public BigDecimal getimporto() {
        return importo;
    }

    public void setimporto(BigDecimal importo) {
        this.importo = importo;
    }

    public int getidOrdine() {
        return idOrdine;
    }

    public void setidOrdine(int idOrdine) {
        this.idOrdine = idOrdine;
    }

    @Override
    public String toString() {
        return "FatturaBean [idFattura=" + idFattura + ", dataFattura=" + dataFattura + ", importo=" + importo
                + ", idOrdine=" + idOrdine + "]";
    }
}
