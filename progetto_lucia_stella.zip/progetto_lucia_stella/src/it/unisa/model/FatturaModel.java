package it.unisa.model;

import java.sql.SQLException;
import java.util.Collection;

public interface FatturaModel {
    public void doSave(FatturaBean fattura) throws SQLException;
    public FatturaBean doRetrieveByKey(int idFattura) throws SQLException;
    public Collection<FatturaBean> doRetrieveAll(String order) throws SQLException;
    public FatturaBean doRetrieveByOrder(int idOrdine) throws SQLException;
}
