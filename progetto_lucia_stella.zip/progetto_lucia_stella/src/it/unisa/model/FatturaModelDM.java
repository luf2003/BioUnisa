package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;

//Classe che implementa il modello FatturaModel per gestire le operazioni sui dati delle fatture
public class FatturaModelDM implements FatturaModel {

    // Nome della tabella nel database
    private static final String TABLE_NAME = "fattura";

    // Metodo per salvare una nuova fattura nel database
    @Override
    public synchronized void doSave(FatturaBean fattura) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per inserire una nuova fattura
        String insertSQL = "INSERT INTO " + TABLE_NAME
                + " (dataFattura, importo, idOrdine) VALUES (?, ?, ?)";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(insertSQL);
            // Imposta i parametri della query
            preparedStatement.setDate(1, fattura.getdataFattura());
            preparedStatement.setBigDecimal(2, fattura.getimporto());
            preparedStatement.setInt(3, fattura.getidOrdine());
            // Esegue l'aggiornamento del database
            preparedStatement.executeUpdate();

            // Conferma la transazione
            connection.commit();
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

    // Metodo per recuperare una fattura dal database utilizzando la chiave primaria
    @Override
    public synchronized FatturaBean doRetrieveByKey(int idFattura) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        FatturaBean bean = new FatturaBean();

        // Query SQL per selezionare una fattura tramite idFattura
        String selectSQL = "SELECT * FROM " + TABLE_NAME + " WHERE idFattura = ?";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            // Imposta il parametro della query
            preparedStatement.setInt(1, idFattura);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                bean.setidFattura(rs.getInt("idFattura"));
                bean.setdataFattura(rs.getDate("dataFattura"));
                bean.setimporto(rs.getBigDecimal("importo"));
                bean.setidOrdine(rs.getInt("idOrdine"));
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return bean;
    }

    // Metodo per recuperare tutte le fatture dal database, con opzione di ordinamento
    @Override
    public synchronized Collection<FatturaBean> doRetrieveAll(String order) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        Collection<FatturaBean> fatture = new LinkedList<FatturaBean>();

        // Query SQL per selezionare tutte le fatture
        String selectSQL = "SELECT * FROM " + TABLE_NAME;

        // Aggiunge l'ordinamento se specificato
        if (order != null && !order.equals("")) {
            selectSQL += " ORDER BY " + order;
        }

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                FatturaBean bean = new FatturaBean();
                bean.setidFattura(rs.getInt("idFattura"));
                bean.setdataFattura(rs.getDate("dataFattura"));
                bean.setimporto(rs.getBigDecimal("importo"));
                bean.setidOrdine(rs.getInt("idOrdine"));
                fatture.add(bean);
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return fatture;
    }

    // Metodo per recuperare una fattura dal database utilizzando l'idOrdine
    @Override
    public synchronized FatturaBean doRetrieveByOrder(int idOrdine) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        FatturaBean bean = new FatturaBean();

        // Query SQL per selezionare una fattura tramite idOrdine
        String selectSQL = "SELECT * FROM " + TABLE_NAME + " WHERE idOrdine = ?";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            // Imposta il parametro della query
            preparedStatement.setInt(1, idOrdine);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                bean.setidFattura(rs.getInt("idFattura"));
                bean.setdataFattura(rs.getDate("dataFattura"));
                bean.setimporto(rs.getBigDecimal("importo"));
                bean.setidOrdine(rs.getInt("idOrdine"));
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return bean;
    }
}
