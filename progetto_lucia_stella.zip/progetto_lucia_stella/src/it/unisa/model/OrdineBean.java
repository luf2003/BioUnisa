package it.unisa.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;

public class OrdineBean implements Serializable {

    private static final long serialVersionUID = 1L;

    int idOrdine;
    Date dataOrdine;
    Time oraOrdine;
    BigDecimal totaleOrdine;
    int quantit�;
    String statoOrdine;
    int userId;

    public OrdineBean() {
        idOrdine = -1;
        dataOrdine = null;
        oraOrdine = null;
        totaleOrdine = BigDecimal.ZERO;
        quantit� = 0;
        statoOrdine = "";
        userId = -1;
    }

    public int getidOrdine() {
        return idOrdine;
    }

    public void setidOrdine(int idOrdine) {
        this.idOrdine = idOrdine;
    }

    public Date getdataOrdine() {
        return dataOrdine;
    }

    public void setdataOrdine(Date dataOrdine) {
        this.dataOrdine = dataOrdine;
    }

    public Time getoraOrdine() {
        return oraOrdine;
    }

    public void setoraOrdine(Time oraOrdine) {
        this.oraOrdine = oraOrdine;
    }

    public BigDecimal gettotaleOrdine() {
        return totaleOrdine;
    }

    public void settotaleOrdine(BigDecimal totaleOrdine) {
        this.totaleOrdine = totaleOrdine;
    }

    public int getquantit�() {
        return quantit�;
    }

    public void setquantit�(int quantit�) {
        this.quantit� = quantit�;
    }

    public String getstatoOrdine() {
        return statoOrdine;
    }

    public void setstatoOrdine(String statoOrdine) {
        this.statoOrdine = statoOrdine;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    @Override
    public String toString() {
        return "OrdineBean [idOrdine=" + idOrdine + ", dataOrdine=" + dataOrdine + ", oraOrdine=" + oraOrdine
                + ", totaleOrdine=" + totaleOrdine + ", quantit�=" + quantit� + ", statoOrdine=" + statoOrdine
                + ", idUtente=" + userId + "]";
    }
}