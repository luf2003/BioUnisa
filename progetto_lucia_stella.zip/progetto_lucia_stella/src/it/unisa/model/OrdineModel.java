package it.unisa.model;

import java.sql.SQLException;
import java.util.Collection;
import javax.servlet.http.HttpServletRequest;

public interface OrdineModel {
    public void doSave(OrdineBean ordine) throws SQLException;
    public OrdineBean doRetrieveByKey(int code) throws SQLException;
   	public Collection<OrdineBean> doRetrieveAll(String order) throws SQLException;
    public int retrieveUserId(HttpServletRequest request);
    public Collection<OrdineBean> getOrdiniByUserId(int userId) throws SQLException;
    public  int getLastOrderId() throws SQLException;
}