package it.unisa.model;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Collection;
import java.util.LinkedList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import it.unisa.control.ConfermaOrdine;

import java.util.logging.Logger;

//Implementazione del modello OrdineModel per gestire le operazioni sui dati degli ordini
public class OrdineModelDM implements OrdineModel {

    // Nome della tabella nel database
    private static final String TABLE_NAME = "ordine";

    // Metodo per salvare un nuovo ordine nel database
    @Override
    public synchronized void doSave(OrdineBean ordine) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per inserire un nuovo ordine
        String insertSQL = "INSERT INTO " + OrdineModelDM.TABLE_NAME
                + " (dataOrdine, oraOrdine, totaleOrdine, quantit�, statoOrdine, userId) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            connection.setAutoCommit(false); // Disabilita l'autocommit

            preparedStatement = connection.prepareStatement(insertSQL);
            // Imposta i parametri della query
            preparedStatement.setDate(1, ordine.getdataOrdine());
            preparedStatement.setTime(2, ordine.getoraOrdine());
            preparedStatement.setBigDecimal(3, ordine.gettotaleOrdine());
            preparedStatement.setInt(4, ordine.getquantit�());
            preparedStatement.setString(5, ordine.getstatoOrdine());
            preparedStatement.setInt(6, ordine.getUserId()); // Aggiunge l'ID dell'utente

            // Esegue l'aggiornamento del database
            preparedStatement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback(); // Rollback esplicito in caso di errore
            }
            throw new SQLException("Errore durante il salvataggio dell'ordine: " + e.getMessage());
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.setAutoCommit(true); // Ripristina l'autocommit
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

    // Metodo per recuperare un ordine dal database utilizzando la chiave primaria
    @Override
    public synchronized OrdineBean doRetrieveByKey(int code) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        
        OrdineBean bean = new OrdineBean();

        // Query SQL per selezionare un ordine tramite idOrdine
        String selectSQL = "SELECT * FROM " + OrdineModelDM.TABLE_NAME + " WHERE idOrdine = ?";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            // Imposta il parametro della query
            preparedStatement.setInt(1, code);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                bean.setidOrdine(rs.getInt("idOrdine"));
                bean.setdataOrdine(rs.getDate("dataOrdine"));
                bean.setoraOrdine(rs.getTime("oraOrdine"));
                bean.settotaleOrdine(rs.getBigDecimal("totaleOrdine"));
                bean.setquantit�(rs.getInt("quantit�"));
                bean.setstatoOrdine(rs.getString("statoOrdine"));
                bean.setUserId(rs.getInt("userId")); // per impostare l'ID dell'utente
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return bean;
    }

    // Metodo per recuperare tutti gli ordini dal database, con opzione di ordinamento
    @Override
    public synchronized Collection<OrdineBean> doRetrieveAll(String order) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        
        Collection<OrdineBean> ordini = new LinkedList<OrdineBean>();

        // Query SQL per selezionare tutti gli ordini
        String selectSQL = "SELECT * FROM " + OrdineModelDM.TABLE_NAME;
        
        // Aggiunge l'ordinamento se specificato
        if (order != null && !order.equals("")) {
            selectSQL += " ORDER BY " + order;
        }

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            
            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                OrdineBean bean = new OrdineBean();
                
                bean.setidOrdine(rs.getInt("idOrdine"));
                bean.setdataOrdine(rs.getDate("dataOrdine"));
                bean.setoraOrdine(rs.getTime("oraOrdine"));
                bean.settotaleOrdine(rs.getBigDecimal("totaleOrdine"));
                bean.setquantit�(rs.getInt("quantit�"));
                bean.setstatoOrdine(rs.getString("statoOrdine"));
                bean.setUserId(rs.getInt("userId")); // per impostare l'ID dell'utente
                ordini.add(bean);
            }
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return ordini;
    }
    
    // Metodo per recuperare l'ID dell'utente dalla sessione o dai parametri della richiesta
    @Override
    public synchronized int retrieveUserId(HttpServletRequest request) {
        // Prova a recuperare l'ID dell'utente dalla sessione
        HttpSession session = request.getSession(false); // Non crea una nuova sessione se non esiste
        if (session != null) {
            Object userIdObject = session.getAttribute("userId"); // Supponendo che l'ID dell'utente sia memorizzato come attributo nella sessione
            if (userIdObject instanceof Integer) {
                return (Integer) userIdObject;
            }
        }
        
        // Se l'ID dell'utente non � stato trovato nella sessione, prova a recuperarlo dai parametri della richiesta
        String userIdParameter = request.getParameter("userId"); // Supponendo che l'ID dell'utente sia passato come parametro nella richiesta
        if (userIdParameter != null) {
            try {
                return Integer.parseInt(userIdParameter);
            } catch (NumberFormatException e) {
            }
        }
        
        // Se non � possibile recuperare l'ID dell'utente dalla sessione o dai parametri della richiesta, restituisci un valore predefinito o gestisci l'errore di conseguenza
        return -1; // Restituzione di un valore predefinito in caso di fallimento
    }

    // Metodo per recuperare tutti gli ordini di un utente specifico
    public synchronized Collection<OrdineBean> getOrdiniByUserId(int userId) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Collection<OrdineBean> ordini = new LinkedList<OrdineBean>();

        // Query SQL per selezionare tutti gli ordini di un utente specifico
        String selectSQL = "SELECT * FROM " + OrdineModelDM.TABLE_NAME + " WHERE userId = ?";
        
        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setInt(1, userId);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                OrdineBean ordine = new OrdineBean();
                ordine.setidOrdine(rs.getInt("idOrdine"));
                ordine.setdataOrdine(rs.getDate("dataOrdine"));
                ordine.setoraOrdine(rs.getTime("oraOrdine"));
                ordine.settotaleOrdine(rs.getBigDecimal("totaleOrdine"));
                ordine.setquantit�(rs.getInt("quantit�"));
                ordine.setstatoOrdine(rs.getString("statoOrdine"));
                ordine.setUserId(rs.getInt("userId")); //per impostare l'ID dell'utente

                ordini.add(ordine);
            }
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }

        return ordini;
    }

    // Metodo per recuperare tutti gli ordini dal database
    public synchronized Collection<OrdineBean> getAllOrdini() throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Collection<OrdineBean> ordini = new LinkedList<OrdineBean>();

        // Query SQL per selezionare tutti gli ordini
        String selectSQL = "SELECT * FROM " + OrdineModelDM.TABLE_NAME;
        
        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                OrdineBean ordine = new OrdineBean();
                ordine.setidOrdine(rs.getInt("idOrdine"));
                ordine.setdataOrdine(rs.getDate("dataOrdine"));
                ordine.setoraOrdine(rs.getTime("oraOrdine"));
                ordine.settotaleOrdine(rs.getBigDecimal("totaleOrdine"));
                ordine.setquantit�(rs.getInt("quantit�"));
                ordine.setstatoOrdine(rs.getString("statoOrdine"));
                ordine.setUserId(rs.getInt("userId"));

                ordini.add(ordine);
            }

            if (ordini.isEmpty()) { //Nessun ordine trovato.
            } else { //Numero di ordini recuperati
            }
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }

        return ordini;
    }
    
    // Metodo per recuperare l'ID dell'ultimo ordine inserito nel database
    public synchronized int getLastOrderId() throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        int orderId = 0;

        // Query SQL per selezionare l'ID dell'ultimo ordine inserito
        String selectSQL = "SELECT idOrdine FROM " + TABLE_NAME + " ORDER BY idOrdine DESC LIMIT 1";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            rs = preparedStatement.executeQuery();

            if (rs.next()) {
                orderId = rs.getInt("idOrdine");
            }
        } finally {
            // Chiude il PreparedStatement e il ResultSet, poi rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
                if (rs != null)
                    rs.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return orderId;
    }
    
}