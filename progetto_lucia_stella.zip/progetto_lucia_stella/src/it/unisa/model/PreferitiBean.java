package it.unisa.model;

import java.io.Serializable;

public class PreferitiBean implements Serializable {

    private static final long serialVersionUID = 1L;

    int idPreferiti;
    int idUtente;
    int idProdotto;

    public PreferitiBean() {
        idPreferiti = -1;
        idUtente = -1;
        idProdotto = -1;
    }

    public int getidPreferiti() {
        return idPreferiti;
    }

    public void setidPreferiti(int idPreferiti) {
        this.idPreferiti = idPreferiti;
    }

    public int getidUtente() {
        return idUtente;
    }

    public void setidUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public int getidProdotto() {
        return idProdotto;
    }

    public void setidProdotto(int idProdotto) {
        this.idProdotto = idProdotto;
    }

    @Override
    public String toString() {
        return "PreferitiBean [idPreferiti=" + idPreferiti + ", idUtente=" + idUtente + ", idProdotto=" + idProdotto + "]";
    }
}
