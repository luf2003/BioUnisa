package it.unisa.model;

import java.sql.SQLException;
import java.util.List;

public interface PreferitiModel {
    public void doSave(PreferitiBean preferito) throws Exception;
    public List<Integer> getFavoriteProductIds(int userId) throws Exception;	
    public void rimuoviDaPreferiti(int userId, int productId) throws SQLException;
}