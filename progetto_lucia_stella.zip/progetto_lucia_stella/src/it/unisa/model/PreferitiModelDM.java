package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//Classe che gestisce le operazioni sul modello "Preferiti" nel database
public class PreferitiModelDM {

    // Metodo per salvare un preferito nel database
    public void doSave(PreferitiBean preferito) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per inserire un nuovo preferito
        String insertSQL = "INSERT INTO preferiti (idUtente, idProdotto) VALUES (?, ?)";

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(insertSQL);
            // Imposta i parametri della query
            preparedStatement.setInt(1, preferito.getidUtente());
            preparedStatement.setInt(2, preferito.getidProdotto());
            // Esegue l'aggiornamento del database
            preparedStatement.executeUpdate();

            connection.commit();
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

    // Metodo per ottenere gli ID dei prodotti preferiti di un utente
    public List<Integer> getFavoriteProductIds(int userId) throws Exception {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per selezionare gli ID dei prodotti preferiti di un utente
        String selectSQL = "SELECT idProdotto FROM preferiti WHERE idUtente = ?";
        List<Integer> favoriteProductIds = new ArrayList<>();

        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            // Imposta il parametro della query
            preparedStatement.setInt(1, userId);
            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                favoriteProductIds.add(rs.getInt("idProdotto"));
            }
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return favoriteProductIds;
    }
    
    // Metodo per rimuovere un prodotto dai preferiti di un utente
    public void rimuoviDaPreferiti(int userId, int productId) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        
        // Query SQL per eliminare un prodotto dai preferiti di un utente
        String deleteSQL = "DELETE FROM preferiti WHERE idUtente = ? AND idProdotto = ?";
        
        try {
            // Ottiene una connessione dal pool
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(deleteSQL);
            // Imposta i parametri della query
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, productId);
            // Esegue l'aggiornamento del database
            preparedStatement.executeUpdate();
            connection.commit();  // per assicurare che le modifiche vengano salvate
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

}
