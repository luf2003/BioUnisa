package it.unisa.model;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

public class ProdottoBean implements Serializable {

    private static final long serialVersionUID = 1L;

    int idProdotto;
    String nome;
    String descrizione;
    String categoria;
    String formato;
    double prezzoUnitario;
    int quantitaDisponibile;
    String percorsoimmagine;
    int quantitaScelta;

    public ProdottoBean() {
        idProdotto = -1;
        nome = "";
        descrizione = "";
        categoria = "";
        formato = "";
        prezzoUnitario = 0.0;
        quantitaDisponibile = 0;
        percorsoimmagine = "";
    }

    public int getidProdotto() {
        return idProdotto;
    }

    public void setidProdotto(int idProdotto) {
        this.idProdotto = idProdotto;
    }

    public String getnome() {
        return nome;
    }

    public void setnome(String nome) {
        this.nome = nome;
    }

    public String getdescrizione() {
        return descrizione;
    }

    public void setdescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getcategoria() {
        return categoria;
    }

    public void setcategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getformato() {
        return formato;
    }

    public void setformato(String formato) {
        this.formato = formato;
    }

    public double getprezzoUnitario() {
        return prezzoUnitario;
    }

    public void setprezzoUnitario(double prezzoUnitario) {
        this.prezzoUnitario = prezzoUnitario;
    }

    public int getquantitaDisponibile() {
        return quantitaDisponibile;
    }

    public void setquantitaDisponibile(int quantitaDisponibile) {
        this.quantitaDisponibile = quantitaDisponibile;
    }
    
    // Aggiungi metodi get e set per il percorso dell'immagine
    public String getpercorsoimmagine() {
        return percorsoimmagine;
    }

    public void setpercorsoimmagine(String percorsoimmagine) {
        this.percorsoimmagine = percorsoimmagine;
    }
    
    public List<String> getFormatiDisponibili() {
        // Per semplicità, restituiamo un elenco contenente solo il formato del prodotto corrente
        List<String> formati = new ArrayList<>();
        formati.add(formato);
        return formati;
    }
    
    public int getquantitaScelta() {
        if (this.quantitaScelta <= 0) {
            return 1; // Imposta il valore predefinito a 1 se è 0 o negativo
        } else {
            return this.quantitaScelta;
        }
    }

    public void setquantitaScelta(int quantitaScelta) {
        this.quantitaScelta = quantitaScelta;
    }
    
    @Override
    public String toString() {
        return nome + " (ID: " + idProdotto + "), Categoria: " + categoria + ", Formato: " + formato + ", Prezzo: " + prezzoUnitario + ", Quantità: " + quantitaDisponibile + ". " + descrizione + ", Percorso Immagine: " + percorsoimmagine;
    }

}

