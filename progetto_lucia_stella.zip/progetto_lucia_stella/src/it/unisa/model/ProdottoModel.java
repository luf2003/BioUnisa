package it.unisa.model;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

public interface ProdottoModel {
	public void doSave(ProdottoBean prodotto) throws SQLException;
	public  ProdottoBean doRetrieveByKey(int code) throws SQLException;
	public Collection<ProdottoBean> doRetrieveAll(String order) throws SQLException;
	public void doUpdate(ProdottoBean prodotto) throws SQLException;
    public void doDelete(int idProdotto) throws SQLException;
    public List<ProdottoBean> getProductsByIds(List<Integer> ids) throws SQLException;
    public void aggiornaQuantitaDisponibile(int prodottoId, int quantitaVenduta) throws SQLException;
}
