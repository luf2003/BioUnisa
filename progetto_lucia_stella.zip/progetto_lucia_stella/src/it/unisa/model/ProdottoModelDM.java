package it.unisa.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


//Implementazione del modello per la gestione dei prodotti nel database
public class ProdottoModelDM implements ProdottoModel {

    private static final String TABLE_NAME = "prodotto";


    // Metodo per salvare un prodotto nel database
    @Override
    public synchronized void doSave(ProdottoBean prodotto) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per inserire o aggiornare un prodotto
        String insertSQL = "INSERT INTO " + ProdottoModelDM.TABLE_NAME
                + " (nome,descrizione,categoria, formato, prezzoUnitario, quantitaDisponibile,percorsoimmagine) VALUES (?,?,?,?,?,?,?) "
                + "ON DUPLICATE KEY UPDATE nome=?, descrizione=?, categoria=?, formato=?, prezzoUnitario=?, quantitaDisponibile=?, percorsoimmagine=?";

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(insertSQL);
            // Imposta i parametri della query per l'inserimento
            preparedStatement.setString(1, prodotto.getnome());
            preparedStatement.setString(2, prodotto.getdescrizione());
            preparedStatement.setString(3, prodotto.getcategoria());
            preparedStatement.setString(4, prodotto.getformato());
            preparedStatement.setDouble(5, prodotto.getprezzoUnitario());
            preparedStatement.setInt(6, prodotto.getquantitaDisponibile());
            preparedStatement.setString(7, prodotto.getpercorsoimmagine());

            // Imposta i parametri della query per l'aggiornamento in caso di chiave duplicata
            preparedStatement.setString(8, prodotto.getnome());
            preparedStatement.setString(9, prodotto.getdescrizione());
            preparedStatement.setString(10, prodotto.getcategoria());
            preparedStatement.setString(11, prodotto.getformato());
            preparedStatement.setDouble(12, prodotto.getprezzoUnitario());
            preparedStatement.setInt(13, prodotto.getquantitaDisponibile());
            preparedStatement.setString(14, prodotto.getpercorsoimmagine());

            // Esegue l'aggiornamento del database
            preparedStatement.executeUpdate();
            connection.commit();
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

    // Metodo per recuperare un singolo prodotto dal database in base all'ID
    @Override
    public synchronized ProdottoBean doRetrieveByKey(int code) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        ProdottoBean bean = new ProdottoBean();

        // Query SQL per selezionare un prodotto in base al suo ID
        String selectSQL = "SELECT * FROM " + ProdottoModelDM.TABLE_NAME + " WHERE idProdotto = ?";

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setInt(1, code);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                bean.setidProdotto(rs.getInt("idProdotto"));
                bean.setnome(rs.getString("nome"));
                bean.setdescrizione(rs.getString("descrizione"));
                bean.setcategoria(rs.getString ("categoria"));
                bean.setformato(rs.getString ("formato"));
                bean.setprezzoUnitario(rs.getDouble("prezzoUnitario"));
                bean.setquantitaDisponibile(rs.getInt("quantitaDisponibile"));
                bean.setpercorsoimmagine(rs.getString("percorsoimmagine"));
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return bean;
    }
   
    // Metodo per recuperare tutti i prodotti dal database, eventualmente ordinati
    @Override
    public synchronized Collection<ProdottoBean> doRetrieveAll(String order) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        Collection<ProdottoBean> prodotti = new LinkedList<ProdottoBean>();
        
        // Query SQL per selezionare tutti i prodotti
        String selectSQL = "SELECT * FROM " + ProdottoModelDM.TABLE_NAME;

        // Aggiunge l'ordine alla query se specificato
        if (order != null && !order.equals("")) {
            selectSQL += " ORDER BY " + order;
        }

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                ProdottoBean bean = new ProdottoBean();

                bean.setidProdotto(rs.getInt("idProdotto"));
                bean.setnome(rs.getString("nome"));
                bean.setdescrizione(rs.getString("descrizione"));
                bean.setcategoria(rs.getString ("categoria"));
                bean.setformato(rs.getString ("formato"));
                bean.setprezzoUnitario(rs.getDouble("prezzoUnitario"));
                bean.setquantitaDisponibile(rs.getInt("quantitaDisponibile"));  // Usa il nome esatto della colonna nel database
                bean.setpercorsoimmagine(rs.getString("percorsoimmagine"));
                prodotti.add(bean);
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return prodotti;
    }
    
    // Metodo per aggiornare un prodotto nel database
    @Override
    public synchronized void doUpdate(ProdottoBean prodotto) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per aggiornare un prodotto
        String updateSQL = "UPDATE " + ProdottoModelDM.TABLE_NAME + " SET nome=?, descrizione=?, categoria=?, formato=?, prezzoUnitario=?, quantitaDisponibile=?, percorsoimmagine=? WHERE idProdotto=?";

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(updateSQL);
            // Imposta i parametri della query
            preparedStatement.setString(1, prodotto.getnome());
            preparedStatement.setString(2, prodotto.getdescrizione());
            preparedStatement.setString(3, prodotto.getcategoria());
            preparedStatement.setString(4, prodotto.getformato());
            preparedStatement.setDouble(5, prodotto.getprezzoUnitario());
            preparedStatement.setInt(6, prodotto.getquantitaDisponibile());
            preparedStatement.setString(7, prodotto.getpercorsoimmagine());
            preparedStatement.setInt(8, prodotto.getidProdotto());

            // Esegue l'aggiornamento del database
            preparedStatement.executeUpdate();
            connection.commit();
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

    // Metodo utilizzato dall'amministratore per cancellare un prodotto
    @Override
    public synchronized void doDelete(int idProdotto) throws SQLException {
        Connection connection = null;
        //Utilizzo due PreparedStatement: 
        //uno per eliminare i riferimenti nella tabella preferiti
        PreparedStatement deletePreferitiStmt = null;
        //uno per eliminare il prodotto nella tabella prodotto
        PreparedStatement deleteProdottoStmt = null;

        // SQL per eliminare i riferimenti nella tabella preferiti
        String deletePreferitiSQL = "DELETE FROM preferiti WHERE idProdotto=?";
        // SQL per eliminare il prodotto dalla tabella prodotto
        String deleteProdottoSQL = "DELETE FROM " + ProdottoModelDM.TABLE_NAME + " WHERE idProdotto=?";

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            connection.setAutoCommit(false);  // Inizia una transazione

            // Elimina i riferimenti nella tabella preferiti
            deletePreferitiStmt = connection.prepareStatement(deletePreferitiSQL);
            deletePreferitiStmt.setInt(1, idProdotto);
            deletePreferitiStmt.executeUpdate();

            // Elimina il prodotto dalla tabella prodotto
            deleteProdottoStmt = connection.prepareStatement(deleteProdottoSQL);
            deleteProdottoStmt.setInt(1, idProdotto);
            deleteProdottoStmt.executeUpdate();

            connection.commit();  // Commette la transazione
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback();  // Rollback in caso di errore
            }
            throw new RuntimeException(e);
        } finally {
            // Chiude i PreparedStatement e rilascia la connessione
            try {
                if (deletePreferitiStmt != null) {
                    deletePreferitiStmt.close();
                }
                if (deleteProdottoStmt != null) {
                    deleteProdottoStmt.close();
                }
                if (connection != null) {
                    DriverManagerConnectionPool.releaseConnection(connection);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    
    //Metodo  per recuperare pi� prodotti in base a una lista di ID
    public List<ProdottoBean> getProductsByIds(List<Integer> ids) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        List<ProdottoBean> products = new ArrayList<>();

        // Restituisce una lista vuota se non ci sono ID
        if (ids.isEmpty()) {
            return products;
        }

        // Costruisce la query per selezionare i prodotti in base agli ID
        StringBuilder queryBuilder = new StringBuilder("SELECT * FROM prodotto WHERE idProdotto IN (");
        for (int i = 0; i < ids.size(); i++) {
            queryBuilder.append("?");
            if (i < ids.size() - 1) {
                queryBuilder.append(",");
            }
        }
        queryBuilder.append(")");

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(queryBuilder.toString());
            // Imposta i parametri della query
            for (int i = 0; i < ids.size(); i++) {
                preparedStatement.setInt(i + 1, ids.get(i));
            }

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                ProdottoBean bean = new ProdottoBean();
                bean.setidProdotto(rs.getInt("idProdotto"));
                bean.setnome(rs.getString("nome"));
                bean.setdescrizione(rs.getString("descrizione"));
                bean.setcategoria(rs.getString("categoria"));
                bean.setformato(rs.getString("formato"));
                bean.setprezzoUnitario(rs.getDouble("prezzoUnitario"));
                bean.setquantitaDisponibile(rs.getInt("quantitaDisponibile"));
                bean.setpercorsoimmagine(rs.getString("percorsoimmagine"));
                products.add(bean);
            }

        } catch (SQLException e) {
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                // Chiude il PreparedStatement e rilascia la connessione
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return products;
    }
    
    //metodo per aggiornare la quantit� disponibile dopo che un prodotto � stato acquistato
    public synchronized void aggiornaQuantitaDisponibile(int prodottoId, int quantitaScelta) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per aggiornare la quantit� disponibile
        String updateSQL = "UPDATE " + ProdottoModelDM.TABLE_NAME + " SET quantitaDisponibile = quantitaDisponibile - ? WHERE idProdotto = ?";

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();

            connection.setAutoCommit(false); // Disabilita l'autocommit

            preparedStatement = connection.prepareStatement(updateSQL);
            preparedStatement.setInt(1, quantitaScelta);
            preparedStatement.setInt(2, prodottoId);
            preparedStatement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback(); // Rollback esplicito in caso di errore
            }
            throw new SQLException("Errore durante l'aggiornamento della quantit� del prodotto: " + e.getMessage());
        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.setAutoCommit(true); // Ripristina l'autocommit
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }
}
