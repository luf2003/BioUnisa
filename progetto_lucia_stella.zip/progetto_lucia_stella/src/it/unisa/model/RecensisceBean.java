package it.unisa.model;

import java.util.Date;

public class RecensisceBean {
    private int valutazione;
    private String testoRecensione;
    private Date dataRecensione;
    private String oraRecensione;
    private int idProdotto;
    private int idUtente;
    private String NomeUtente;


    public int getValutazione() {
        return valutazione;
    }

    public void setValutazione(int valutazione) {
        this.valutazione = valutazione;
    }

    public String getTestoRecensione() {
        return testoRecensione;
    }

    public void setTestoRecensione(String testoRecensione) {
        this.testoRecensione = testoRecensione;
    }

    public Date getDataRecensione() {
        return dataRecensione;
    }

    public void setDataRecensione(Date dataRecensione) {
        this.dataRecensione = dataRecensione;
    }

    public String getOraRecensione() {
        return oraRecensione;
    }

    public void setOraRecensione(String oraRecensione) {
        this.oraRecensione = oraRecensione;
    }

    public int getIdProdotto() {
        return idProdotto;
    }

    public void setIdProdotto(int idProdotto) {
        this.idProdotto = idProdotto;
    }

    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }
    
    public String getNomeUtente() {
        return NomeUtente;
    }

    public void setNomeUtente(String NomeUtente) {
        this.NomeUtente = NomeUtente;
    }
}