package it.unisa.model;

import java.sql.SQLException;
import java.util.List;

public interface RecensisceModel {
    List<RecensisceBean> getRecensioni() throws SQLException;
    boolean saveRecensione(RecensisceBean recensione) throws SQLException;
    List<RecensisceBean> getRecensioniByUser(String userId) throws SQLException;
}