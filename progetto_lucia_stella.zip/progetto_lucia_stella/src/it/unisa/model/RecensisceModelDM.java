package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//Implementazione del modello per la gestione delle recensioni nel database
public class RecensisceModelDM implements RecensisceModel {
    private static final String TABLE_NAME = "recensisce";
    
    // Metodo per recuperare tutte le recensioni dal database
    @Override
    public List<RecensisceBean> getRecensioni() throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        
        // Query SQL per selezionare tutte le recensioni e le informazioni dell'utente
        String selectSQL = "SELECT r.Valutazione, r.TestoRecensione, r.DataRecensione, r.OraRecensione, r.idProdotto, r.idUtente, u.nome " +
                "FROM " + TABLE_NAME + " r JOIN utente u ON r.idUtente = u.idUtente";

        List<RecensisceBean> recensioni = new ArrayList<>();

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                RecensisceBean recensione = new RecensisceBean();
                recensione.setValutazione(rs.getInt("Valutazione"));
                recensione.setTestoRecensione(rs.getString("TestoRecensione"));
                recensione.setDataRecensione(rs.getDate("DataRecensione"));
                recensione.setOraRecensione(rs.getString("OraRecensione"));
                recensione.setIdProdotto(rs.getInt("idProdotto"));
                recensione.setIdUtente(rs.getInt("idUtente"));
                recensione.setNomeUtente(rs.getString("nome"));
                recensioni.add(recensione);
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return recensioni;
    }
    
    // Metodo per salvare una recensione nel database
    @Override
    public boolean saveRecensione(RecensisceBean recensione) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean isSaved = false;

        // Query SQL per verificare se una recensione esiste gi�
        String checkSQL = "SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE idProdotto = ? AND idUtente = ?";
        // Query SQL per inserire una nuova recensione
        String insertSQL = "INSERT INTO " + TABLE_NAME + " (idProdotto, Valutazione, TestoRecensione, DataRecensione, OraRecensione, idUtente) VALUES (?, ?, ?, CURDATE(), CURTIME(), ?)";
        // Query SQL per aggiornare una recensione esistente
        String updateSQL = "UPDATE " + TABLE_NAME + " SET Valutazione = ?, TestoRecensione = ?, DataRecensione = CURDATE(), OraRecensione = CURTIME() WHERE idProdotto = ? AND idUtente = ?";

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            connection.setAutoCommit(false); // Disabilita l'autocommit

            // Verifica se la recensione esiste gi�
            preparedStatement = connection.prepareStatement(checkSQL);
            preparedStatement.setInt(1, recensione.getIdProdotto());
            preparedStatement.setInt(2, recensione.getIdUtente());
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next() && resultSet.getInt(1) > 0) {
                // Se la recensione esiste gi�, esegue l'aggiornamento
                preparedStatement = connection.prepareStatement(updateSQL);
                preparedStatement.setInt(1, recensione.getValutazione());
                preparedStatement.setString(2, recensione.getTestoRecensione());
                preparedStatement.setInt(3, recensione.getIdProdotto());
                preparedStatement.setInt(4, recensione.getIdUtente());
            } else {
                // Se la recensione non esiste, esegue l'inserimento
                preparedStatement = connection.prepareStatement(insertSQL);
                preparedStatement.setInt(1, recensione.getIdProdotto());
                preparedStatement.setInt(2, recensione.getValutazione());
                preparedStatement.setString(3, recensione.getTestoRecensione());
                preparedStatement.setInt(4, recensione.getIdUtente());
            }

            // Esegue l'aggiornamento o l'inserimento nel database
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                connection.commit(); // Esegue il commit della transazione
                isSaved = true;
                System.out.println("Recensione salvata nel database.");
            } else {
                connection.rollback(); // Esegui il rollback in caso di errore
                System.out.println("Nessuna riga modificata, rollback eseguito.");
            }
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback(); // Rollback esplicito in caso di errore
            }
            throw new SQLException("Errore durante il salvataggio della recensione: " + e.getMessage());
        } finally {
            // Chiude il ResultSet, il PreparedStatement e ripristina l'autocommit
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.setAutoCommit(true); // Ripristina l'autocommit
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }

        return isSaved;
    }

    // Metodo per recuperare tutte le recensioni di un utente specifico
    @Override
    public List<RecensisceBean> getRecensioniByUser(String userId) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        // Query SQL per selezionare tutte le recensioni di un utente specifico
        String selectSQL = "SELECT r.Valutazione, r.TestoRecensione, r.DataRecensione, r.OraRecensione, r.idProdotto, r.idUtente, u.nome " +
                "FROM " + TABLE_NAME + " r JOIN utente u ON r.idUtente = u.idUtente WHERE r.idUtente = ?";

        List<RecensisceBean> recensioni = new ArrayList<>();

        try {
            // Ottiene una connessione dal pool di connessioni
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setString(1, userId);

            // Esegue la query
            ResultSet rs = preparedStatement.executeQuery();

            // Processa il ResultSet
            while (rs.next()) {
                RecensisceBean recensione = new RecensisceBean();
                recensione.setValutazione(rs.getInt("Valutazione"));
                recensione.setTestoRecensione(rs.getString("TestoRecensione"));
                recensione.setDataRecensione(rs.getDate("DataRecensione"));
                recensione.setOraRecensione(rs.getString("OraRecensione"));
                recensione.setIdProdotto(rs.getInt("idProdotto"));
                recensione.setIdUtente(rs.getInt("idUtente"));
                recensione.setNomeUtente(rs.getString("nome"));
                recensioni.add(recensione);
            }

        } finally {
            // Chiude il PreparedStatement e rilascia la connessione
            try {
                if (preparedStatement != null) preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }

        return recensioni;
    }
}