package it.unisa.model;

import java.io.Serializable;

public class UtenteBean implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private int idUtente;
    private String username; // Questo campo sarà usato per l'email
    private String nome;
    private String cognome;
    private String email;
    private String telefono;
    private String password;
    private String nuovoRecapito;
    private String indirizzo;
    private String citta;
    private String provincia;
    private String cap;
    private String stato;
    private String profileImagePath;

    public UtenteBean() {
        idUtente = -1;
        username = "";
        nome = "";
        cognome = "";
        email = "";
        telefono="";
        nuovoRecapito = "";
        password = "";
        indirizzo = "";
        citta = "";
        provincia = "";
        cap = "";
        stato = "";
        profileImagePath = "";
    }

    public int getidUtente() {
        return idUtente;
    }

    public void setidUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }

    public String getnome() {
        return nome;
    }

    public void setnome(String nome) {
        this.nome = nome;
    }

    public String getcognome() {
        return cognome;
    }

    public void setcognome(String cognome) {
        this.cognome = cognome;
    }

    public String getemail() {
        return email;
    }

    public String gettelefono() {
        return telefono;
    }

    public void settelefono(String telefono) {
        this.telefono = telefono;
    }
    
    public String getnuovoRecapito() {
        return nuovoRecapito;
    }

    public void setnuovoRecapito(String nuovoRecapito) {
        this.nuovoRecapito = nuovoRecapito;
    }
    
    public void setemail(String email) {
        this.email = email;
    }

    public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }

    public String getindirizzo() {
        return indirizzo;
    }

    public void setindirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getcitta() {
        return citta;
    }

    public void setcitta(String citta) {
        this.citta = citta;
    }

    public String getprovincia() {
        return provincia;
    }

    public void setprovincia(String provincia) {
        this.provincia = provincia;
    }

    public String getcap() {
        return cap;
    }

    public void setcap(String cap) {
        this.cap = cap;
    }

    public String getstato() {
        return stato;
    }

    public void setstato(String stato) {
        this.stato = stato;
    }
    
    public String getProfileImagePath() {
        return profileImagePath;
    }

    public void setProfileImagePath(String profileImagePath) {
        this.profileImagePath = profileImagePath;
    }
}
