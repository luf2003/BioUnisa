package it.unisa.model;

import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

public interface UtenteModel {
    public void doSave(UtenteBean utente) throws SQLException;
    public UtenteBean doRetrieveByEmail(String email) throws SQLException;
    public UtenteBean doRetrieveByEmailAndPassword(String email, String password) throws SQLException;
    public UtenteBean doRetrieveByKey(int idUtente) throws SQLException;
    public Collection<UtenteBean> doRetrieveAll(String order) throws SQLException;  
    public void doUpdate(UtenteBean utente) throws SQLException;
    public Collection<UtenteBean> cercaUtentiPerNome(String search) throws SQLException;
    public Collection<UtenteBean> cercaUtentiPerEmail(String email) throws SQLException;
    public Collection<UtenteBean> filtraUtenti(char from, char to) throws SQLException;
}
