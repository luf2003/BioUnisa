package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

//Implementazione del modello per la gestione degli utenti nel database
public class UtenteModelDM implements UtenteModel {

    private static final String TABLE_NAME = "utente";

    // Salva un nuovo utente nel database
    @Override
    public synchronized void doSave(UtenteBean utente) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String insertSQL = "INSERT INTO " + UtenteModelDM.TABLE_NAME
                + " (username, nome, cognome, email, telefono, nuovoRecapito, password, indirizzo, citta, provincia, cap, stato, profileImagePath) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            connection = DriverManagerConnectionPool.getConnection();
            connection.setAutoCommit(false); // Disabilita l'autocommit

            preparedStatement = connection.prepareStatement(insertSQL);
            preparedStatement.setString(1, utente.getusername());
            preparedStatement.setString(2, utente.getnome());
            preparedStatement.setString(3, utente.getcognome());
            preparedStatement.setString(4, utente.getemail());
            preparedStatement.setString(5, utente.gettelefono());
            preparedStatement.setString(6, utente.getnuovoRecapito());
            preparedStatement.setString(7, utente.getpassword());
            preparedStatement.setString(8, utente.getindirizzo());
            preparedStatement.setString(9, utente.getcitta());
            preparedStatement.setString(10, utente.getprovincia());
            preparedStatement.setString(11, utente.getcap());
            preparedStatement.setString(12, utente.getstato());
            preparedStatement.setString(13, utente.getProfileImagePath());
            preparedStatement.executeUpdate();

            connection.commit();
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback(); // Rollback esplicito in caso di errore
            }
            throw new SQLException("Errore durante il salvataggio dell'utente: " + e.getMessage());
        } finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.setAutoCommit(true); // Ripristina l'autocommit
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }

    // Recupera un utente dal database in base all'email
    @Override
    public synchronized UtenteBean doRetrieveByEmail(String email) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        UtenteBean bean = null;

        String selectSQL = "SELECT * FROM " + UtenteModelDM.TABLE_NAME + " WHERE email = ?";

        try {
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setString(1, email);

            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                bean = new UtenteBean();

                bean.setidUtente(rs.getInt("idUtente"));
                bean.setusername(rs.getString("email")); // Utilizziamo l'email come username
                bean.setnome(rs.getString("nome"));
                bean.setcognome(rs.getString("cognome"));
                bean.setemail(rs.getString("email"));
                bean.settelefono(rs.getString("telefono"));
                bean.setnuovoRecapito(rs.getString("nuovoRecapito"));
                bean.setpassword(rs.getString("password"));
                bean.setindirizzo(rs.getString("indirizzo"));
                bean.setcitta(rs.getString("citta"));
                bean.setprovincia(rs.getString("provincia"));
                bean.setcap(rs.getString("cap"));
                bean.setstato(rs.getString("stato"));
                bean.setProfileImagePath(rs.getString("profileImagePath"));
                
            }
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return bean;
    }

    // Recupera un utente dal database in base a email e password
    @Override
    public UtenteBean doRetrieveByEmailAndPassword(String email, String password) throws SQLException {
        // Usa la funzione checkUserLogin per ottenere l'utente
        return CheckUserAdminPassword.checkUserLogin(email, password);
    }

    // Recupera un utente dal database in base all'ID
    @Override
    public synchronized UtenteBean doRetrieveByKey(int code) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        UtenteBean bean = new UtenteBean();

        String selectSQL = "SELECT * FROM " + UtenteModelDM.TABLE_NAME + " WHERE idUtente = ?";

        try {
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setInt(1, code);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                bean.setidUtente(rs.getInt("idUtente"));
                bean.setusername(rs.getString("username"));
                bean.setnome(rs.getString("nome"));
                bean.setcognome(rs.getString("cognome"));
                bean.setemail(rs.getString("email"));
                bean.settelefono(rs.getString("telefono"));
                bean.setnuovoRecapito(rs.getString("nuovoRecapito"));
                bean.setpassword(rs.getString("password"));
                bean.setindirizzo(rs.getString("indirizzo"));
                bean.setcitta(rs.getString("citta"));
                bean.setprovincia(rs.getString("provincia"));
                bean.setcap(rs.getString("cap"));
                bean.setstato(rs.getString("stato"));
                bean.setProfileImagePath(rs.getString("profileImagePath"));

            }
        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return bean;
    }

    // Recupera tutti gli utenti dal database
    @Override
    public synchronized Collection<UtenteBean> doRetrieveAll(String order) throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        Collection<UtenteBean> utenti = new LinkedList<>();

        String selectSQL = "SELECT * FROM " + UtenteModelDM.TABLE_NAME + " WHERE email <> 'root@gmail.com'";

        if (order != null && !order.equals("")) {
            selectSQL += " ORDER BY " + order;
        }

        try {
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                UtenteBean bean = new UtenteBean();

                bean.setidUtente(rs.getInt("idUtente"));
                bean.setusername(rs.getString("username"));
                bean.setnome(rs.getString("nome"));
                bean.setcognome(rs.getString("cognome"));
                bean.setemail(rs.getString("email"));
                bean.settelefono(rs.getString("telefono"));
                bean.setnuovoRecapito(rs.getString("nuovoRecapito"));
                bean.setpassword(rs.getString("password"));
                bean.setindirizzo(rs.getString("indirizzo"));
                bean.setcitta(rs.getString("citta"));
                bean.setprovincia(rs.getString("provincia"));
                bean.setcap(rs.getString("cap"));
                bean.setstato(rs.getString("stato"));
                bean.setProfileImagePath(rs.getString("profileImagePath"));
                utenti.add(bean);
            }

        } finally {
            try {
                if (preparedStatement != null)
                    preparedStatement.close();
            } finally {
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
        return utenti;
    }

    // Aggiorna i dati di un utente nel database
    @Override
    public synchronized void doUpdate(UtenteBean utente) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = DriverManagerConnectionPool.getConnection();
            connection.setAutoCommit(false); // Disabilita l'autocommit

            // Recupera l'utente dal database per mantenere i valori esistenti
            String selectSQL = "SELECT * FROM " + UtenteModelDM.TABLE_NAME + " WHERE idUtente = ?";
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setInt(1, utente.getidUtente());
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                // Mantiene la password esistente se non � stata fornita una nuova password
                if (utente.getpassword() == null || utente.getpassword().isEmpty()) {
                    utente.setpassword(rs.getString("password"));
                }

                // Mantiene l'immagine del profilo esistente se non � stata fornita una nuova immagine
                if (utente.getProfileImagePath() == null || utente.getProfileImagePath().isEmpty()) {
                    utente.setProfileImagePath(rs.getString("profileImagePath"));
                }

                // Aggiorna solo i campi necessari
                String updateSQL = "UPDATE " + UtenteModelDM.TABLE_NAME
                        + " SET nome = ?, cognome = ?, email = ?, telefono = ?, nuovoRecapito = ?, password = ?, indirizzo = ?, citta = ?, provincia = ?, cap = ?, stato = ?, profileImagePath = ? WHERE idUtente = ?";
                preparedStatement = connection.prepareStatement(updateSQL);
                preparedStatement.setString(1, utente.getnome());
                preparedStatement.setString(2, utente.getcognome());
                preparedStatement.setString(3, utente.getemail());
                preparedStatement.setString(4, utente.gettelefono());
                preparedStatement.setString(5, utente.getnuovoRecapito());
                preparedStatement.setString(6, utente.getpassword());
                preparedStatement.setString(7, utente.getindirizzo());
                preparedStatement.setString(8, utente.getcitta());
                preparedStatement.setString(9, utente.getprovincia());
                preparedStatement.setString(10, utente.getcap());
                preparedStatement.setString(11, utente.getstato());
                preparedStatement.setString(12, utente.getProfileImagePath());
                preparedStatement.setInt(13, utente.getidUtente());
                preparedStatement.executeUpdate();

                connection.commit();
            }
        } catch (SQLException e) {
            if (connection != null) {
                connection.rollback(); // Rollback esplicito in caso di errore
            }
            throw new SQLException("Errore durante l'aggiornamento del profilo utente: " + e.getMessage());
        } finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.setAutoCommit(true); // Ripristina l'autocommit
                DriverManagerConnectionPool.releaseConnection(connection);
            }
        }
    }
    
    // Cerca utenti per nome
    public Collection<UtenteBean> cercaUtentiPerNome(String search) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Collection<UtenteBean> utenti = new LinkedList<>();

        String selectSQL = "SELECT * FROM " + TABLE_NAME + " WHERE nome LIKE ? AND email <> 'root@gmail.com'";

        try {
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setString(1, "%" + search + "%");

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                UtenteBean bean = new UtenteBean();
                bean.setidUtente(rs.getInt("idUtente"));
                bean.setusername(rs.getString("username"));
                bean.setnome(rs.getString("nome"));
                bean.setcognome(rs.getString("cognome"));
                bean.setemail(rs.getString("email"));
                bean.settelefono(rs.getString("telefono"));
                bean.setnuovoRecapito(rs.getString("nuovoRecapito"));
                bean.setpassword(rs.getString("password"));
                bean.setindirizzo(rs.getString("indirizzo"));
                bean.setcitta(rs.getString("citta"));
                bean.setprovincia(rs.getString("provincia"));
                bean.setcap(rs.getString("cap"));
                bean.setstato(rs.getString("stato"));
                bean.setProfileImagePath(rs.getString("profileImagePath"));
                utenti.add(bean);
            }
            
        } finally {
            if (preparedStatement != null)
                preparedStatement.close();
            DriverManagerConnectionPool.releaseConnection(connection);
        }
        return utenti;
    }

    // Cerca utenti per email
    public Collection<UtenteBean> cercaUtentiPerEmail(String email) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Collection<UtenteBean> utenti = new LinkedList<>();

        String selectSQL = "SELECT * FROM " + TABLE_NAME + " WHERE email LIKE ? AND email <> 'root@gmail.com'";

        try {
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setString(1, "%" + email + "%");

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                UtenteBean bean = new UtenteBean();
                bean.setidUtente(rs.getInt("idUtente"));
                bean.setusername(rs.getString("username"));
                bean.setnome(rs.getString("nome"));
                bean.setcognome(rs.getString("cognome"));
                bean.setemail(rs.getString("email"));
                bean.settelefono(rs.getString("telefono"));
                bean.setnuovoRecapito(rs.getString("nuovoRecapito"));
                bean.setpassword(rs.getString("password"));
                bean.setindirizzo(rs.getString("indirizzo"));
                bean.setcitta(rs.getString("citta"));
                bean.setprovincia(rs.getString("provincia"));
                bean.setcap(rs.getString("cap"));
                bean.setstato(rs.getString("stato"));
                bean.setProfileImagePath(rs.getString("profileImagePath"));
                utenti.add(bean);
            }
            
        } finally {
            if (preparedStatement != null)
                preparedStatement.close();
            DriverManagerConnectionPool.releaseConnection(connection);
        }
        return utenti;
    }

    // Filtra utenti per intervallo alfabetico
    public Collection<UtenteBean> filtraUtenti(char from, char to) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Collection<UtenteBean> utenti = new LinkedList<>();

        String selectSQL = "SELECT * FROM " + TABLE_NAME + " WHERE nome BETWEEN ? AND ? ORDER BY nome";

        try {
            connection = DriverManagerConnectionPool.getConnection();
            preparedStatement = connection.prepareStatement(selectSQL);
            preparedStatement.setString(1, String.valueOf(from));
            preparedStatement.setString(2, String.valueOf(to) + "z"); // aggiungiamo "z" per includere la lettera finale

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                UtenteBean bean = new UtenteBean();
                bean.setidUtente(rs.getInt("idUtente"));
                bean.setusername(rs.getString("username"));
                bean.setnome(rs.getString("nome"));
                bean.setcognome(rs.getString("cognome"));
                bean.setemail(rs.getString("email"));
                bean.settelefono(rs.getString("telefono"));
                bean.setnuovoRecapito(rs.getString("nuovoRecapito"));
                bean.setpassword(rs.getString("password"));
                bean.setindirizzo(rs.getString("indirizzo"));
                bean.setcitta(rs.getString("citta"));
                bean.setprovincia(rs.getString("provincia"));
                bean.setcap(rs.getString("cap"));
                bean.setstato(rs.getString("stato"));
                bean.setProfileImagePath(rs.getString("profileImagePath"));
                utenti.add(bean);
            }

        } finally {
            if (preparedStatement != null)
                preparedStatement.close();
            DriverManagerConnectionPool.releaseConnection(connection);
        }
        return utenti;
    }


}
